"""Configuration loading with dotted-key overrides (used by the sensitivity study)."""
import copy
import json
import os

import yaml

DEFAULT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "configs", "default.yaml")


class Cfg(dict):
    """dict with attribute access (cfg.gat.hidden_dim)."""

    def __getattr__(self, k):
        try:
            v = self[k]
        except KeyError as e:
            raise AttributeError(k) from e
        return v

    def __setattr__(self, k, v):
        self[k] = v

    def __deepcopy__(self, memo):
        return _wrap(copy.deepcopy(dict(self), memo))


def _wrap(d):
    if isinstance(d, dict):
        return Cfg({k: _wrap(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_wrap(v) for v in d]
    return d


def load_config(path=None, overrides=None):
    with open(path or DEFAULT) as f:
        cfg = _wrap(yaml.safe_load(f))
    for k, v in (overrides or {}).items():
        set_dotted(cfg, k, v)
    return cfg


def set_dotted(cfg, key, value):
    parts = key.split(".")
    d = cfg
    for p in parts[:-1]:
        d = d[p]
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (ValueError, TypeError):
            pass
    d[parts[-1]] = _wrap(value)


def get_dotted(cfg, key):
    d = cfg
    for p in key.split("."):
        d = d[p]
    return d


def parse_overrides(items):
    """['a.b=1', 'c=[1,2]'] -> {'a.b': '1', 'c': '[1,2]'}"""
    out = {}
    for it in items or []:
        k, v = it.split("=", 1)
        out[k] = v
    return out
