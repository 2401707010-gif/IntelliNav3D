"""Baseline values copied from the original publications, exactly as listed in Tables 3-7 of the manuscript.
They are NOT computed by this code. Each entry names its source paper and table."""

ROOMS = ["Bedroom", "Living room", "Dining room"]

# Table 3: FID (lower is better)
TABLE3_FID = [
    ("ATISS [25]", "[25], Table 1", {"Bedroom": 38.39, "Living room": 33.14, "Dining room": 29.23}),
    ("DiffuScene [24]", "[24], Table 1", {"Bedroom": 17.21, "Living room": 36.18, "Dining room": 32.60}),
    ("PhyScene [33]", "[33], Table 2", {"Bedroom": 28.56, "Living room": 40.67, "Dining room": 37.88}),
    ("CHOrD [22]", "[22], Table 1", {"Bedroom": 14.78, "Living room": 24.15, "Whole house": 11.51}),
    ("SemLayoutDiff [23]", "[23], Table 12", {"Bedroom": 75.42, "Living room": 66.90, "Dining room": 70.87}),
    ("Nav2Scene (ATISS + fine-tuning) [19]", "[19], Table 2", {"Bedroom": 21.47, "Living room": 43.78, "Dining room": 40.08}),
    ("Nav2Scene (DiffuScene + fine-tuning) [19]", "[19], Table 2", {"Bedroom": 26.95, "Living room": 44.91, "Dining room": 39.01}),
]

# Table 4: objects out of room (%) and walkable space (%)
TABLE4 = [
    ("ATISS", "[33], Table 3", {"Bedroom": (28.6, 83.9), "Living room": (13.6, 81.4), "Dining room": (13.2, 87.4)}),
    ("DiffuScene", "[33], Table 3", {"Bedroom": (27.2, 82.7), "Living room": (23.8, 79.0), "Dining room": (24.4, 78.7)}),
    ("PhyScene [33]", "[33], Table 3", {"Bedroom": (24.5, 86.5), "Living room": (21.9, 81.5), "Dining room": (21.7, 85.2)}),
    ("SemLayoutDiff [23]", "[23], Table 13", {"Bedroom": (4.00, 93.80), "Living room": (8.32, 95.92), "Dining room": (7.53, 99.36)}),
]

# Table 5: accessibility (%)
TABLE5 = [
    ("ATISS", "[33], Table 3", {"Bedroom": 83.9, "Living room": 81.4, "Dining room": 87.4}),
    ("DiffuScene", "[33], Table 3", {"Bedroom": 82.7, "Living room": 79.0, "Dining room": 78.7}),
    ("PhyScene [33]", "[33], Table 3", {"Bedroom": 86.5, "Living room": 81.5, "Dining room": 85.2}),
]

# Table 6: path planning score (PPS) of Nav2Scene (no navigation success rate is published)
TABLE6_PPS = [
    ("ATISS", "[19], Table 1", {"Bedroom": 0.86, "Living room": 0.84, "Dining room": 0.91}),
    ("DiffuScene", "[19], Table 1", {"Bedroom": 0.87, "Living room": 0.83, "Dining room": 0.92}),
    ("Nav2Scene (ATISS + fine-tuning) [19]", "[19], Table 1", {"Bedroom": 0.94, "Living room": 0.92, "Dining room": 0.97}),
    ("Nav2Scene (DiffuScene + fine-tuning) [19]", "[19], Table 1", {"Bedroom": 0.96, "Living room": 0.93, "Dining room": 0.99}),
]

# Table 7: object collision rate (%) = share of objects intersecting another object (superscript a)
TABLE7 = [
    ("ATISS", "[33], Table 3", {"Bedroom": 24.8, "Living room": 31.6, "Dining room": 59.1}),
    ("DiffuScene", "[33], Table 3", {"Bedroom": 22.8, "Living room": 19.8, "Dining room": 16.0}),
    ("PhyScene [33]", "[33], Table 3", {"Bedroom": 18.7, "Living room": 19.1, "Dining room": 15.1}),
    ("SemLayoutDiff [23]", "[23], Table 13", {"Bedroom": 26.21, "Living room": 16.82, "Dining room": 5.37}),
    ("ATISS", "[36], Table 4", {"SceneEval-500, mixed rooms": 50.36}),
    ("DiffuScene", "[36], Table 4", {"SceneEval-500, mixed rooms": 31.81}),
    ("Holodeck", "[36], Table 4", {"SceneEval-500, mixed rooms": 15.91}),
]

ROOM_KEY = {"Bedroom": "bedroom", "Living room": "livingroom", "Dining room": "diningroom", "All test rooms": "all"}
