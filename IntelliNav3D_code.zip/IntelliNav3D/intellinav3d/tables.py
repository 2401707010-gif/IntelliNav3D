"""Builds Tables 1-15 from results/results.json (written by scripts/run_experiments.py).

Values of this work are always computed from the experiment outputs; baseline rows of Tables 3-7 are the
published values in published.py. Missing experiments appear as '–' with a note.
"""
import os

import numpy as np
import pandas as pd

from . import published as P
from .data.split import load_split
from .stats import holm, paired_test, summary

DASH = "–"
ROOM_ORDER = [("Bedroom", "bedroom"), ("Living room", "livingroom"), ("Dining room", "diningroom")]


def f(x, nd=1):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return DASH
    return f"{x:.{nd}f}"


# ------------------------------------------------------------------------------------------
# access helpers
# ------------------------------------------------------------------------------------------
def seeds_of(res, tag, variant):
    return res.get(tag, {}).get(variant, {})


def per_seed(res, tag, variant, getter):
    vals = {}
    for s, e in seeds_of(res, tag, variant).items():
        try:
            v = getter(e)
        except (KeyError, TypeError):
            continue
        if v is not None:
            vals[int(s)] = float(v)
    return vals


def metric(room, key, sub="metrics_scenes"):
    return lambda e: e[sub][room][key]


def fid_of(room):
    return lambda e: e["fid"][room]


def mean_of(res, tag, variant, getter):
    v = per_seed(res, tag, variant, getter)
    return float(np.mean(list(v.values()))) if v else None


# ------------------------------------------------------------------------------------------
def table1():
    rows = [("D", "3D-FRONT dataset"), ("G (V,E)", "Indoor scene graph"), ("Z", "Spatial relationship embedding"),
            ("S_t", "Diffusion process state"), ("ANS", "Adaptive Navigation Score"), ("CP", "Collision penalty"),
            ("P_s", "Path efficiency"), ("C_s", "Collision avoidance score"), ("A_s", "Accessibility score"),
            ("S*", "Final optimized scene")]
    return pd.DataFrame(rows, columns=["Symbol", "Description"]), "Table 1: Key Notations", ""


def table2(cfg):
    try:
        cnt = load_split(cfg.paths.split_file)["meta"]["counts"]
    except (FileNotFoundError, KeyError):
        cnt = {"train": DASH, "val": DASH, "test": DASH}
    rows = [("Dataset", "3D-FRONT"), ("Training Scenes", f"{cnt['train']:,}" if isinstance(cnt['train'], int) else DASH),
            ("Validation Scenes", f"{cnt['val']:,}" if isinstance(cnt['val'], int) else DASH),
            ("Test Scenes", f"{cnt['test']:,}" if isinstance(cnt['test'], int) else DASH),
            ("Graph Learning", "Graph Attention Network (GAT)"), ("Diffusion Model", "Navigation-Conditioned DDPM"),
            ("Reinforcement Learning", "PPO"), ("Optimizer", "Adam"), ("Learning Rate", str(cfg.ddpm.lr)),
            ("Batch Size", str(cfg.ddpm.batch_size)), ("Hidden Dimension", str(cfg.gat.hidden_dim)),
            ("Attention Heads", str(cfg.gat.heads)), ("Diffusion Steps", str(cfg.ddpm.timesteps)),
            ("PPO Clip Ratio", str(cfg.ppo.clip)), ("Discount Factor (γ)", str(cfg.ppo.gamma)),
            ("Training Epochs", str(cfg.ddpm.epochs)), ("Framework", "PyTorch")]
    note = "Scene counts are read from the split file actually used (data/split.json)."
    return pd.DataFrame(rows, columns=["Parameter", "Value"]), "Table 2: Experimental Configuration", note


def _ours_rows(res, getter_by_room, fmt_nd, rooms=ROOM_ORDER + [("All test rooms", "all")]):
    out = []
    for label, key in rooms:
        out.append((label, f(mean_of(res, "main", "full", getter_by_room(key)), fmt_nd)))
    return out


def table3(res):
    rows = []
    for name, src, vals in P.TABLE3_FID:
        for room, v in vals.items():
            rows.append((name, src, room, f(v, 2)))
    for room, v in _ours_rows(res, fid_of, 2):
        rows.append(("IntelliNav3D (proposed)", "This work", room, v))
    df = pd.DataFrame(rows, columns=["Method", "Values taken from", "Room type", "FID ↓"])
    note = ("Baseline values are copied from the cited papers (not recomputed). IntelliNav3D values: mean over seeds "
            "of the FID computed by this code (Section 4.8 protocol).")
    return df, "Table 3: Scene-Quality Results on 3D-FRONT as compared with existing models", note


def table4(res):
    rows = []
    for name, src, vals in P.TABLE4:
        for room, (o, w) in vals.items():
            rows.append((name, src, room, f(o, 2), f(w, 2)))
    for label, key in ROOM_ORDER + [("All test rooms", "all")]:
        o = mean_of(res, "main", "full", metric(key, "objects_out_of_room"))
        w = mean_of(res, "main", "full", metric(key, "accessibility"))
        rows.append(("IntelliNav3D (proposed)", "This work", label, f(o, 2), f(w, 1)))
    df = pd.DataFrame(rows, columns=["Method", "Values taken from", "Room type", "Objects out of room (%) ↓",
                                     "Walkable space (%) ↑"])
    return df, "Table 4: Robot-Navigation and Physical-Plausibility Results on 3D-FRONT", \
        "Walkable space of IntelliNav3D = accessibility (reachable share of the inflated free floor, Section 4.1.2)."


def table5(res):
    rows = [(n, s, r, f(v, 1)) for n, s, vals in P.TABLE5 for r, v in vals.items()]
    rows += [("IntelliNav3D (proposed)", "This work", r, v) for r, v in _ours_rows(res, lambda k: metric(k, "accessibility"), 1)]
    return pd.DataFrame(rows, columns=["Method", "Values taken from", "Room type", "Accessibility (%)"]), \
        "Table 5: Accessibility of IntelliNav3D Compared with Values Published for Generated Indoor Scenes", ""


def table6(res):
    rows = [(n, s, r, DASH, f(v, 2)) for n, s, vals in P.TABLE6_PPS for r, v in vals.items()]
    rows += [("IntelliNav3D (proposed)", "This work", r, v, DASH)
             for r, v in _ours_rows(res, lambda k: metric(k, "navigation_success"), 1)]
    return pd.DataFrame(rows, columns=["Method", "Values taken from", "Room type", "Navigation success (%) ↑",
                                       "Path planning score ↑"]), \
        "Table 6: Navigation Success Rate of IntelliNav3D Compared with Values Published for Generated Indoor Scenes", \
        "PPS and success rate are different quantities and are listed in separate columns."


def table7(res):
    rows = [(n, s, r, f(v, 2) + " a") for n, s, vals in P.TABLE7 for r, v in vals.items()]
    rows += [("IntelliNav3D (proposed)", "This work", r, v + (" b" if v != DASH else ""))
             for r, v in _ours_rows(res, lambda k: metric(k, "collision_rate"), 1)]
    note = ("a: percentage of objects that intersect another object (published). b: percentage of navigation trials "
            "with at least one robot-obstacle contact (this work). The object-level overlap rate of IntelliNav3D is "
            "also computed by this code and listed in TableS1_roomwise.")
    return pd.DataFrame(rows, columns=["Method", "Values taken from", "Room type / setting", "Collision rate (%) ↓"]), \
        "Table 7: Collision Rate of IntelliNav3D Compared with Values Published for Generated Indoor Scenes", note


VARIANT_LABEL = [("full", "Full IntelliNav3D"), ("no_gat", "Without GAT"), ("no_ddpm", "Without DDPM"),
                 ("no_ppo", "Without PPO"), ("no_monff", "Without MONFF")]


def table8(res):
    rows = []
    for v, label in VARIANT_LABEL:
        rows.append((label, f(mean_of(res, "main", v, metric("all", "navigation_success"))),
                     f(mean_of(res, "main", v, metric("all", "collision_rate"))),
                     f(mean_of(res, "main", v, metric("all", "accessibility"))),
                     f(mean_of(res, "main", v, fid_of("all")), 2)))
    return pd.DataFrame(rows, columns=["Model variant", "Navigation Success (%)", "Collision Rate (%)",
                                       "Accessibility Score (%)", "FID ↓"]), \
        "Table 8: Ablation Study of the Proposed IntelliNav3D Framework", "Mean over the seeds that were run for each variant."


def table9(res):
    keys = [("Path Efficiency", "path_efficiency"), ("Collision Avoidance", "collision_avoidance"),
            ("Accessibility Score", "accessibility_score"), ("Spatial Consistency", "spatial_consistency"),
            ("Human Comfort", "human_comfort_score"), ("MONFF", "monff")]
    rows = [(n, f(mean_of(res, "main", "full", metric("all", k)), 3)) for n, k in keys]
    return pd.DataFrame(rows, columns=["Metric", "Value"]), \
        "Table 9: Navigation Performance Analysis of the Proposed IntelliNav3D Framework", \
        "MONFF is the mean over test rooms of Eq. (13) including the collision term."


def table10(cfg):
    rows = [("Hidden Dimension", cfg.gat.hidden_dim), ("Attention Heads", cfg.gat.heads), ("Learning Rate", cfg.ppo.lr),
            ("Batch Size", cfg.ddpm.batch_size), ("PPO Clip Ratio", cfg.ppo.clip), ("PPO Epochs", cfg.ppo.epochs),
            ("Discount Factor (γ)", cfg.ppo.gamma), ("GAE Lambda", cfg.ppo.gae_lambda),
            ("Diffusion Time Steps", cfg.ddpm.timesteps), ("Optimizer", "Adam")]
    return pd.DataFrame([(a, str(b)) for a, b in rows], columns=["Hyperparameter", "Value"]), \
        "Table 10: Hyperparameter Configuration of the Proposed IntelliNav3D Framework", ""


STAT_METRICS = [("Navigation Success (%)", metric("all", "navigation_success"), 1),
                ("Collision Rate (%)", metric("all", "collision_rate"), 1),
                ("Accessibility (%)", metric("all", "accessibility"), 1),
                ("FID", fid_of("all"), 2),
                ("Human Comfort", metric("all", "human_comfort"), 1)]


def table11(res):
    rows = []
    for name, g, nd in STAT_METRICS:
        v = list(per_seed(res, "main", "full", g).values())
        if v:
            s = summary(v)
            rows.append((name, f(s["mean"], nd), f(s["sd"], 2), "±" + f(s["ci95"], 2), s["n"]))
        else:
            rows.append((name, DASH, DASH, DASH, 0))
    return pd.DataFrame(rows, columns=["Metric", "Mean", "Std. Dev.", "95% Confidence Interval", "n (seeds)"]), \
        "Table 11: Statistical Analysis of the Proposed IntelliNav3D Framework Across Different Evaluation Metrics", \
        "CI = t(0.975, n-1) * s / sqrt(n) over independent seeds."


def table12(res):
    """Paired tests (same seeds, same test rooms and start-goal pairs) of IntelliNav3D against every other
    method that has per-seed results: ablation variants and externally evaluated baselines."""
    comps = [(v, lab, "main") for v, lab in VARIANT_LABEL[1:]]
    for name in sorted(res.get("external_methods", {})):
        comps.append((name, name, "external_methods"))
    rows, ps = [], []
    for v, lab, tag in comps:
        for mname, g, nd in STAT_METRICS:
            a = per_seed(res, "main", "full", g)
            b = per_seed(res, tag, v, g)
            common = sorted(set(a) & set(b))
            if len(common) < 2:
                continue
            t = paired_test([a[s] for s in common], [b[s] for s in common])
            rows.append([mname, lab, f(t["mean_diff"], 2), f"[{f(t['ci_low'], 2)}, {f(t['ci_high'], 2)}]", t["p"], t["n"]])
            ps.append(t["p"])
    if rows:
        adj = holm([p if np.isfinite(p) else 1.0 for p in ps])
        for r, p in zip(rows, adj):
            r[4] = "<0.001" if p < 0.001 else f"{p:.3f}"
    df = pd.DataFrame(rows, columns=["Metric", "Compared with", "Mean difference", "95% CI of difference",
                                     "Holm-corrected p-value", "n (paired seeds)"])
    note = ("Mean difference = IntelliNav3D minus the compared method over seeds evaluated on the same test rooms and "
            "start-goal pairs. Published baseline values cannot enter a paired test; baselines appear here only if their "
            "layouts were re-generated and evaluated with scripts/evaluate_external.py for the same seeds.")
    return df, "Table 12: Significance Tests of IntelliNav3D Against Compared Methods", note


def table13(res):
    def pl(variant, which):
        return mean_of(res, "main", variant, lambda e: e["plausibility"][which]["objects_outside_pct"]), \
            mean_of(res, "main", variant, lambda e: e["plausibility"][which]["doors_blocked_pct"]), \
            mean_of(res, "main", variant, lambda e: e["plausibility"][which]["wall_support_violations_pct"]), \
            mean_of(res, "main", variant, lambda e: e["plausibility"][which]["mean_displacement_m"])
    rows = []
    o, d, w, m = pl("full", "before_ppo")
    rows.append(("Diffusion output (before PPO)", f(o, 2), f(d, 2), f(w, 2), f(m, 3),
                 f(mean_of(res, "main", "full", metric("all", "navigation_success", "metrics_pre")))))
    o, d, w, m = pl("unconstrained", "after_ppo")
    rows.append(("After unconstrained PPO (reference)", f(o, 2), f(d, 2), f(w, 2), f(m, 3),
                 f(mean_of(res, "main", "unconstrained", metric("all", "navigation_success")))))
    o, d, w, m = pl("full", "after_ppo")
    rows.append(("After constrained PPO (proposed)", f(o, 2), f(d, 2), f(w, 2), f(m, 3),
                 f(mean_of(res, "main", "full", metric("all", "navigation_success")))))
    return pd.DataFrame(rows, columns=["Layout", "Objects outside room (%)", "Doors blocked (%)",
                                       "Wall/support violations (%)", "Mean displacement (m)", "Navigation Success (%)"]), \
        "Table 13: Plausibility Statistics Before and After PPO Refinement", \
        "Before PPO = the selected diffusion candidate that was refined into the final layout."


FACTOR_LABEL = {"gat.hidden_dim": "GAT hidden dimension", "gat.heads": "GAT heads", "ddpm.timesteps": "Diffusion steps",
                "ppo.clip": "PPO clip ratio", "monff.collision_lambda": "Collision penalty λ",
                "graph.distance_threshold": "Graph distance threshold", "monff.weights": "MONFF weights"}


def table14(res, cfg):
    rows = []
    for factor, values in cfg.experiments.sensitivity.items():
        tags = [t for t in res if t.startswith(f"sens/{factor}=")]
        ns, cr, fd, tested = [], [], [], []
        for t in sorted(tags):
            tested.append(t.split("=", 1)[1])
            for lst, g in ((ns, metric("all", "navigation_success")), (cr, metric("all", "collision_rate")),
                           (fd, fid_of("all"))):
                v = mean_of(res, t, "full", g)
                if v is not None:
                    lst.append(v)

        def rng(lst, nd):
            return f"{f(min(lst), nd)}-{f(max(lst), nd)}" if lst else DASH
        rows.append((FACTOR_LABEL.get(factor, factor), "[" + " / ".join(map(str, values)) + "]",
                     rng(ns, 1), rng(cr, 1), rng(fd, 2), len(tested)))
    return pd.DataFrame(rows, columns=["Factor", "Values tested", "Navigation Success (%)", "Collision Rate (%)", "FID",
                                       "settings run"]), \
        "Table 14: Sensitivity of IntelliNav3D to Hyperparameters and MONFF Weights", \
        "Range over the settings of each factor (one factor varied at a time); each setting = mean over its seeds."


def table15(res, cfg):
    rows = []
    sets = [("3D-FRONT test split (in-distribution)", "main"),
            (f"Held-out room type ({cfg.experiments.heldout_room_type})", f"heldout_{cfg.experiments.heldout_room_type}"),
            ("Independent dataset", "external")]
    for label, tag in sets:
        if not seeds_of(res, tag, "full"):
            continue
        rows.append((label, f(mean_of(res, tag, "full", metric("all", "navigation_success"))),
                     f(mean_of(res, tag, "full", metric("all", "collision_rate"))),
                     f(mean_of(res, tag, "full", metric("all", "accessibility"))),
                     f(mean_of(res, tag, "full", fid_of("all")), 2)))
    note = ("Only settings that were actually run are listed. A physics-simulator execution is not part of this code "
            "and therefore has no row.")
    return pd.DataFrame(rows, columns=["Setting", "Navigation Success (%)", "Collision Rate (%)", "Accessibility (%)",
                                       "FID"]), "Table 15: Generalization Experiments", note


def table_s1(res):
    rows = []
    for label, key in ROOM_ORDER + [("Kitchen", "kitchen"), ("All test rooms", "all")]:
        g = lambda k: (lambda e: e["metrics_scenes"][key][k])
        rows.append((label, f(mean_of(res, "main", "full", g("navigation_success"))),
                     f(mean_of(res, "main", "full", g("collision_rate"))),
                     f(mean_of(res, "main", "full", g("accessibility"))),
                     f(mean_of(res, "main", "full", g("human_comfort"))),
                     f(mean_of(res, "main", "full", g("object_overlap_rate")), 2),
                     f(mean_of(res, "main", "full", fid_of(key)), 2)))
    return pd.DataFrame(rows, columns=["Room type", "Navigation Success (%)", "Collision Rate (%)", "Accessibility (%)",
                                       "Human Comfort (%)", "Object overlap rate (%)", "FID"]), \
        "Table S1: Room-wise results of IntelliNav3D (Section 4.3, including kitchens)", ""


def build_all(res, cfg):
    return {
        "Table1": table1(), "Table2": table2(cfg), "Table3": table3(res), "Table4": table4(res), "Table5": table5(res),
        "Table6": table6(res), "Table7": table7(res), "Table8": table8(res), "Table9": table9(res),
        "Table10": table10(cfg), "Table11": table11(res), "Table12": table12(res), "Table13": table13(res),
        "Table14": table14(res, cfg), "Table15": table15(res, cfg), "TableS1_roomwise": table_s1(res),
    }


def to_markdown(df):
    cols = [str(c) for c in df.columns]
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(v) for v in r) + " |")
    return "\n".join(lines)


def write_all(tables, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    md = []
    for name, (df, title, note) in tables.items():
        df.to_csv(os.path.join(out_dir, f"{name}.csv"), index=False)
        md.append(f"## {title}\n\n" + to_markdown(df) + (f"\n\n*{note}*" if note else "") + "\n")
    with open(os.path.join(out_dir, "all_tables.md"), "w") as fh:
        fh.write("\n".join(md))
    try:
        from docx import Document
        from docx.shared import Pt
        doc = Document()
        for name, (df, title, note) in tables.items():
            doc.add_paragraph().add_run(title).bold = True
            t = doc.add_table(rows=1, cols=len(df.columns))
            t.style = "Table Grid"
            for j, c in enumerate(df.columns):
                t.rows[0].cells[j].text = str(c)
            for _, r in df.iterrows():
                cells = t.add_row().cells
                for j, v in enumerate(r):
                    cells[j].text = str(v)
            for row in t.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        for run in p.runs:
                            run.font.size = Pt(8)
            if note:
                doc.add_paragraph(note).runs[0].italic = True
            doc.add_paragraph()
        doc.save(os.path.join(out_dir, "all_tables.docx"))
    except ImportError:
        print("python-docx not installed: all_tables.docx skipped (CSV and Markdown written)")
