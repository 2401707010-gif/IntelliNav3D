"""Non-diffusion placement used by the 'without DDPM' ablation (Table 8).

Each object is placed at the normalised position and orientation of a randomly chosen training
instance of the same category in the same room type, rescaled to the target room. PPO then refines it.
"""
import numpy as np

from .scene import Scene


def heuristic_layout(template: Scene, stats, rng):
    out = template.copy()
    lo, hi = out.bounds()
    ext = hi - lo
    for o in out.objects:
        cand = stats["positions"].get(f"{out.room_type}|{o.category}")
        if cand:
            px, py, th = cand[rng.integers(len(cand))]
        else:
            px, py, th = rng.uniform(0.2, 0.8), rng.uniform(0.2, 0.8), rng.uniform(-np.pi, np.pi)
        o.x = float(lo[0] + px * ext[0])
        o.y = float(lo[1] + py * ext[1])
        o.theta = float(th)
    for o in out.objects:
        if o.parent >= 0:
            p = out.objects[o.parent]
            o.x, o.y = p.x, p.y
    return out
