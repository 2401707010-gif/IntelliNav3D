"""Figures 1-12 of the manuscript.

Figs. 2 and 8 are diagrams; Figs. 3, 4, 6 and 7 use the worked-example bedroom (examples.py) exactly as in
Sections 3.2-3.5; Fig. 5 needs a trained DDPM; Figs. 1, 9 and 10 use real / generated test rooms; Figs. 11 and 12
combine published baseline values with the results of this code.
"""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches as mpatches  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from . import published as P  # noqa: E402
from .collision import collision_map, collision_penalty, pair_gaps  # noqa: E402
from .examples import example_bedroom  # noqa: E402
from .geometry import fraction_outside  # noqa: E402
from .graph import build_graph, undirected_edges  # noqa: E402
from .navigation import navigation_metrics, sample_pairs  # noqa: E402
from .render import PALETTE  # noqa: E402
from .scene import Scene, keepout_region  # noqa: E402

DPI = 300


def _save(fig, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    p = os.path.join(out_dir, name)
    fig.savefig(p, dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    return p


def draw_scene(ax, sc, title=None, label=False, highlight=None, alpha=0.9, show_doors=True):
    fl = np.vstack([sc.floor_np, sc.floor_np[:1]])
    ax.fill(fl[:, 0], fl[:, 1], color="#ececec", zorder=0)
    ax.plot(fl[:, 0], fl[:, 1], color="k", lw=1.5, zorder=1)
    order = sorted(range(len(sc.objects)), key=lambda i: sc.objects[i].z + sc.objects[i].h)
    for i in order:
        o = sc.objects[i]
        c = np.array(PALETTE.get(o.category, (90, 90, 90))) / 255
        poly = mpatches.Polygon(o.corners(), closed=True, fc=c, ec="k", lw=0.6, alpha=alpha, zorder=2)
        ax.add_patch(poly)
        if label:
            ax.text(o.x, o.y, o.category.replace("_", "\n"), ha="center", va="center", fontsize=5, zorder=5)
        if highlight and i in highlight:
            cc = o.corners()
            lo, hi = cc.min(0) - 0.05, cc.max(0) + 0.05
            ax.add_patch(mpatches.Rectangle(lo, *(hi - lo), fill=False, ec=highlight[i], lw=1.4, zorder=6))
    if show_doors:
        for op in sc.openings:
            ko = keepout_region(op, 0.5)
            ax.add_patch(mpatches.Polygon(ko, closed=True, fc="none", ec="#1f77b4" if op.kind == "door" else "#17becf",
                                          lw=0.8, ls="--", zorder=1))
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    if title:
        ax.set_title(title, fontsize=8)


def problem_objects(sc, cfg):
    """Objects involved in overlaps or lying (partly) outside the room -> red boxes in Figs. 9-10."""
    bad = {}
    for i, j, g in pair_gaps(sc, cfg.navigation.get("robot_height", 0.12)):
        if g < -0.01:
            bad[i] = bad[j] = "red"
    for i in sc.floor_object_indices(cfg.navigation.get("robot_height", 0.12)):
        if fraction_outside(sc.objects[i].corners(), sc.floor_np) > 0.01:
            bad[i] = "red"
    return bad


# ------------------------------------------------------------------------------------------
def fig1(cfg, test_scenes, out_dir):
    by = {}
    for s in test_scenes:
        by.setdefault(s.room_type, []).append(s)
    rooms = [r for r in ["bedroom", "livingroom", "diningroom", "kitchen"] if r in by]
    fig, axes = plt.subplots(2, max(len(rooms), 1), figsize=(3 * max(len(rooms), 1), 6))
    axes = np.array(axes).reshape(2, -1)
    for j, r in enumerate(rooms):
        for i in range(2):
            ax = axes[i, j]
            if i < len(by[r]):
                draw_scene(ax, by[r][i], f"{r} ({len(by[r][i].objects)} objects)" if i == 0 else None)
            else:
                ax.axis("off")
    cats = sorted({o.category for s in test_scenes for o in s.objects})
    handles = [mpatches.Patch(color=np.array(PALETTE[c]) / 255, label=c) for c in cats]
    fig.legend(handles=handles, loc="lower center", ncol=min(6, len(handles)), fontsize=6, frameon=False)
    fig.suptitle("3D-FRONT rooms: floor plans, object footprints and semantic categories", fontsize=9)
    return _save(fig, out_dir, "Fig1_dataset.png")


def _boxes(ax, items, arrows, title):
    for (x, y, w, h, text, col) in items:
        ax.add_patch(mpatches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02", fc=col, ec="k", lw=0.8))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=6.5, wrap=True)
    for arr in arrows:
        x0, y0, x1, y1, lab = arr[:5]
        style = arr[5] if len(arr) > 5 else "arc3"
        ls = "--" if style != "arc3" else "-"
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                    arrowprops=dict(arrowstyle="->", lw=1, connectionstyle=style, linestyle=ls))
        if lab:
            ax.text((x0 + x1) / 2, (y0 + y1) / 2 + 0.025, lab, fontsize=6, ha="center", color="#333",
                    bbox=dict(fc="white", ec="none", pad=0.3))
    ax.set_xlim(-0.03, 1.03)
    ax.set_ylim(-0.05, 1.0)
    ax.axis("off")
    ax.set_title(title, fontsize=9)


def fig2(out_dir):
    fig, ax = plt.subplots(figsize=(10, 3.6))
    c = ["#dbe9f6", "#e2f0d9", "#fde9d9", "#fff2cc", "#ead1dc", "#d9d2e9", "#f2f2f2"]
    items = [(0.00, 0.42, 0.10, 0.16, "1. 3D-FRONT\npre-processing", c[0]),
             (0.14, 0.42, 0.11, 0.16, "2. Scene graph\n+ GAT (G*)", c[1]),
             (0.29, 0.42, 0.12, 0.16, "3. Navigation-\nconditioned DDPM\n(candidates)", c[2]),
             (0.47, 0.70, 0.15, 0.16, "4. Adaptive Navigation\nA*: P_s, C_s, A_s, ANS", c[3]),
             (0.47, 0.14, 0.15, 0.16, "5. Collision map\nCP (Eq. 11)", c[4]),
             (0.68, 0.42, 0.13, 0.16, "6. PPO refinement\nreward = ΔMONFF", c[5]),
             (0.86, 0.42, 0.13, 0.16, "S* = argmax\nMONFF", c[6])]
    arrows = [(0.10, 0.5, 0.14, 0.5, ""), (0.25, 0.5, 0.29, 0.5, "G*"), (0.41, 0.55, 0.47, 0.76, ""),
              (0.41, 0.45, 0.47, 0.24, ""), (0.62, 0.78, 0.69, 0.58, "ANS"), (0.62, 0.22, 0.69, 0.42, "CP"),
              (0.745, 0.42, 0.545, 0.30, "", "arc3,rad=-0.35"), (0.81, 0.5, 0.86, 0.5, "")]
    _boxes(ax, items, arrows, "Overall architecture of IntelliNav3D")
    ax.text(0.72, 0.24, "new layout\n(back to 4 and 5)", fontsize=6, color="#333", ha="left")
    return _save(fig, out_dir, "Fig2_architecture.png")


def fig3(cfg, out_dir):
    sc = example_bedroom(False)
    adj, rel, ef = build_graph(sc, cfg.graph.distance_threshold)
    fig, ax = plt.subplots(figsize=(5, 4.6))
    draw_scene(ax, sc, None, label=False, alpha=0.35, show_doors=False)
    for o in sc.objects:
        dy = -0.16 if o.parent < 0 else 0.14
        ax.text(o.x, o.y + dy, o.category.replace("_", " "), ha="center", va="center", fontsize=6, zorder=10)
    col = {1: "#7f7f7f", 2: "#d62728", 3: "#1f77b4"}
    for k, (i, j) in enumerate(undirected_edges(adj)):
        r = max(rel[i, j], rel[j, i])
        a, b = sc.objects[i], sc.objects[j]
        ax.plot([a.x, b.x], [a.y, b.y], color=col[r], lw=1.4, ls="--" if r == 1 else "-", zorder=7)
        if r != 3:
            fr_ = 0.3 if k % 2 else 0.55
            ax.text(a.x + fr_ * (b.x - a.x), a.y + fr_ * (b.y - a.y), f"{ef[i, j, 0]:.2f} m", fontsize=6,
                    zorder=8, bbox=dict(fc="white", ec="none", pad=0.5))
    for o in sc.objects:
        ax.plot(o.x, o.y, "o", color="k", ms=4, zorder=9)
    handles = [plt.Line2D([], [], color=col[2], label="functional"), plt.Line2D([], [], color=col[3], label="support"),
               plt.Line2D([], [], color=col[1], ls="--", label=f"near (< {cfg.graph.distance_threshold} m)")]
    ax.legend(handles=handles, fontsize=6, loc="lower right")
    ax.set_title(f"Scene graph of the 4.0 m x 3.6 m bedroom: |V| = {len(sc.objects)}, |E| = {len(undirected_edges(adj))}",
                 fontsize=8)
    return _save(fig, out_dir, "Fig3_scene_graph.png")


def fig4(cfg, out_dir, seed=0):
    """Forward process q(x_t | x_0) (Eq. 4) applied to the example layout, and the reverse direction."""
    from .encoding import decode_pose, encode_pose, frame
    sc = example_bedroom(False)
    fr = frame(sc)
    x0 = encode_pose(sc, fr)
    T = cfg.ddpm.timesteps
    betas = np.linspace(cfg.ddpm.beta_start, cfg.ddpm.beta_end, T)
    ac = np.cumprod(1 - betas)
    rng = np.random.default_rng(seed)
    eps = rng.standard_normal(x0.shape)
    ts = [0, int(0.1 * T), int(0.3 * T), int(0.6 * T), T - 1]
    fig, axes = plt.subplots(2, len(ts), figsize=(2.2 * len(ts), 4.6))
    for k, t in enumerate(ts):
        xt = np.sqrt(ac[t]) * x0 + np.sqrt(1 - ac[t]) * eps
        s = decode_pose(sc, xt, fr)
        draw_scene(axes[0, k], s, f"t = {t + 1 if t else 0}", show_doors=False)
        draw_scene(axes[1, len(ts) - 1 - k], s, f"t = {t + 1 if t else 0}", show_doors=False)
        for a in (axes[0, k], axes[1, len(ts) - 1 - k]):
            a.set_xlim(-1.5, 5.5)
            a.set_ylim(-1.5, 5.1)
    axes[0, 0].set_ylabel("forward  q(x_t | x_0)", fontsize=8)
    axes[1, 0].set_ylabel("reverse  p_θ(x_{t-1} | x_t, G*)", fontsize=8)
    fig.suptitle("Forward (noising) and reverse (denoising) diffusion of a room layout", fontsize=9)
    return _save(fig, out_dir, "Fig4_diffusion_process.png")


def fig5(steps_by_t, out_dir, title):
    """steps_by_t: {t: Scene} from pipeline.generate_ddpm(..., return_steps=...)."""
    ts = sorted(steps_by_t, reverse=True)
    fig, axes = plt.subplots(1, len(ts), figsize=(2.3 * len(ts), 2.6))
    axes = np.atleast_1d(axes)
    for ax, t in zip(axes, ts):
        draw_scene(ax, steps_by_t[t], f"t = {t}", show_doors=False)
        lo, hi = steps_by_t[t].bounds()
        ax.set_xlim(lo[0] - 1, hi[0] + 1)
        ax.set_ylim(lo[1] - 1, hi[1] + 1)
    fig.suptitle(title, fontsize=9)
    return _save(fig, out_dir, "Fig5_reverse_steps.png")


def fig6(cfg, out_dir):
    sc = example_bedroom(True)
    nav_cfg = cfg.navigation
    pairs = sample_pairs(sc, nav_cfg, k=3)
    nm = navigation_metrics(sc, nav_cfg, pairs, planner="astar", return_paths=True)
    g = nm["grid"]
    ext = [g.lo[0], g.lo[0] + g.nx * g.res, g.lo[1], g.lo[1] + g.ny * g.res]
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6))
    axes[0].imshow(g.occupied, origin="lower", extent=ext, cmap="Greys")
    axes[0].set_title("Step 1: occupancy grid (5 cm)", fontsize=8)
    inf = np.zeros(g.occupied.shape + (3,))
    inf[g.navigable] = (1, 1, 1)
    inf[(~g.navigable) & g.inroom & ~g.occupied] = (1.0, 0.75, 0.5)
    inf[g.occupied] = (0.3, 0.3, 0.3)
    axes[1].imshow(inf, origin="lower", extent=ext)
    axes[1].set_title(f"Step 2: inflation by r = {nav_cfg.robot_radius} m", fontsize=8)
    axes[2].imshow(inf, origin="lower", extent=ext)
    for k, (p, (s, gl)) in enumerate(zip(nm["paths"], pairs)):
        if p is None:
            continue
        xy = np.array([g.to_world(c) for c in p])
        axes[2].plot(xy[:, 0], xy[:, 1], lw=1.5, label=f"pair {k + 1}: {nm['path_lengths'][k]:.2f} m")
        axes[2].plot(*s, "go", ms=4)
        axes[2].plot(*gl, "r*", ms=6)
    axes[2].legend(fontsize=6, loc="upper left")
    axes[2].set_title(f"Steps 3-5: A* paths   P_s={nm['P_s']:.3f}  C_s={nm['C_s']:.3f}  A_s={nm['A_s']:.3f}  "
                      f"ANS={nm['ANS']:.3f}", fontsize=7)
    for a in axes:
        a.set_xticks([])
        a.set_yticks([])
    return _save(fig, out_dir, "Fig6_adaptive_navigation.png")


def fig7(cfg, out_dir):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4))
    cmap = matplotlib.colors.ListedColormap(["white", "#9e9e9e", "#ffbf00", "#d62728"])
    for ax, defects, lab in ((axes[0], True, "(a) generated layout"), (axes[1], False, "(b) after correction")):
        sc = example_bedroom(defects)
        M, g = collision_map(sc, cfg)
        cp, terms = collision_penalty(sc, cfg.collision)
        ext = [g.lo[0], g.lo[0] + g.nx * g.res, g.lo[1], g.lo[1] + g.ny * g.res]
        ax.imshow(M, origin="lower", extent=ext, cmap=cmap, vmin=0, vmax=3, interpolation="nearest")
        for o in sc.objects:
            ax.add_patch(mpatches.Polygon(o.corners(), closed=True, fill=False, ec="k", lw=0.6))
            ax.text(o.x, o.y, o.category.replace("_", "\n"), fontsize=5, ha="center", va="center")
        txt = "\n".join(f"{sc.objects[i].category}-{sc.objects[j].category}: g={gg:+.3f}, term={t:.3f}"
                        for i, j, gg, c, t in terms)
        ax.set_title(f"{lab}: CP = {cp:.3f} m", fontsize=8)
        if txt:
            ax.text(0.0, -0.02, txt, transform=ax.transAxes, fontsize=6, va="top")
        ax.set_xticks([])
        ax.set_yticks([])
    handles = [mpatches.Patch(color=c, label=l) for c, l in
               zip(["white", "#9e9e9e", "#ffbf00", "#d62728"], ["0 free", "1 occupied", "2 clearance violation", "3 overlap"])]
    fig.legend(handles=handles, loc="lower center", ncol=4, fontsize=7, frameon=False, bbox_to_anchor=(0.5, -0.08))
    return _save(fig, out_dir, "Fig7_collision_map.png")


def fig8(out_dir):
    fig, ax = plt.subplots(figsize=(10, 4.2))
    c = "#e8eef7"
    items = [(0.02, 0.75, 0.16, 0.15, "Module 1\nPre-processing\n(Section 3.1)", c),
             (0.24, 0.75, 0.16, 0.15, "Module 2\nScene graph + GAT\n(Algorithm 1)", c),
             (0.46, 0.75, 0.16, 0.15, "Module 3\nDDPM candidates\nS_1 ... S_r", c),
             (0.30, 0.38, 0.17, 0.15, "Module 4\nAdaptive Navigation\nANS (Algorithm 2)", "#fff2cc"),
             (0.56, 0.38, 0.17, 0.15, "Module 5\nCollision map\nCP (Eq. 11)", "#fde9d9"),
             (0.43, 0.04, 0.18, 0.15, "Module 6\nPPO: move/rotate one object\nr_t = ΔMONFF − λ_d||Δp||", "#d9d2e9"),
             (0.80, 0.04, 0.17, 0.15, "MONFF stops improving\nor T_max = 50:\nS* = argmax MONFF", "#e2f0d9")]
    arrows = [(0.18, 0.825, 0.24, 0.825, ""), (0.40, 0.825, 0.46, 0.825, "G*"), (0.54, 0.75, 0.40, 0.53, ""),
              (0.54, 0.75, 0.64, 0.53, ""), (0.385, 0.38, 0.48, 0.19, "ANS"), (0.645, 0.38, 0.56, 0.19, "CP"),
              (0.43, 0.115, 0.35, 0.38, "new layout"), (0.61, 0.115, 0.80, 0.115, "")]
    _boxes(ax, items, arrows, "Workflow of IntelliNav3D (closed refinement loop)")
    return _save(fig, out_dir, "Fig8_workflow.png")


def fig_compare(cfg, rows, method_dirs, out_dir, name, title):
    """rows: list of test scene ids; method_dirs: [(label, dir or None)] -> grid of top-down layouts."""
    fig, axes = plt.subplots(len(rows), len(method_dirs), figsize=(2.4 * len(method_dirs), 2.4 * len(rows)))
    axes = np.array(axes).reshape(len(rows), len(method_dirs))
    for i, sid in enumerate(rows):
        for j, (lab, d) in enumerate(method_dirs):
            ax = axes[i, j]
            p = os.path.join(d, sid + ".json") if d else None
            if p and os.path.exists(p):
                sc = Scene.load(p)
                bad = problem_objects(sc, cfg)
                draw_scene(ax, sc, lab if i == 0 else None, highlight=bad or None)
                if not bad:
                    lo, hi = sc.bounds()
                    ax.add_patch(mpatches.Rectangle(lo, *(hi - lo), fill=False, ec="green", lw=1.2))
            else:
                ax.text(0.5, 0.5, "not evaluated", ha="center", va="center", fontsize=7, color="#888")
                ax.set_xticks([])
                ax.set_yticks([])
                if i == 0:
                    ax.set_title(lab, fontsize=8)
    fig.suptitle(title + "  (red: overlapping / out-of-room objects, green: no conflict)", fontsize=8)
    return _save(fig, out_dir, name)


def fig11(ours, out_dir):
    """ours: dict with keys accessibility, objects_out_of_room, collision_rate, fid (all test rooms)."""
    axes_lab = ["Accessibility", "Objects inside room", "Collision-free*", "Realism (100 − FID)"]

    def mean(d, rooms=("Bedroom", "Living room", "Dining room")):
        v = [d[r] for r in rooms if r in d]
        return float(np.mean(v)) if v else None

    t3 = {n.split(" [")[0]: v for n, _, v in P.TABLE3_FID}
    t4 = {n.split(" [")[0]: v for n, _, v in P.TABLE4}
    t7 = {n.split(" [")[0]: v for n, s, v in P.TABLE7 if "[33]" in s or "[23]" in s}
    series = {}
    for m in ["ATISS", "DiffuScene", "PhyScene", "SemLayoutDiff"]:
        series[m] = [mean({r: x[1] for r, x in t4[m].items()}), 100 - mean({r: x[0] for r, x in t4[m].items()}),
                     100 - mean(t7[m]), 100 - mean(t3[m])]
    if ours and all(ours.get(k) is not None for k in ("accessibility", "objects_out_of_room", "collision_rate", "fid")):
        series["IntelliNav3D"] = [ours["accessibility"], 100 - ours["objects_out_of_room"], 100 - ours["collision_rate"],
                                  100 - ours["fid"]]
    ang = np.linspace(0, 2 * np.pi, len(axes_lab), endpoint=False).tolist()
    ang += ang[:1]
    fig = plt.figure(figsize=(5.2, 5.2))
    ax = fig.add_subplot(111, polar=True)
    for m, v in series.items():
        vv = v + v[:1]
        ax.plot(ang, vv, lw=2 if m == "IntelliNav3D" else 1.2, label=m)
        ax.fill(ang, vv, alpha=0.08)
    ax.set_xticks(ang[:-1])
    ax.set_xticklabels(axes_lab, fontsize=7)
    ax.set_ylim(0, 100)
    ax.legend(fontsize=7, loc="upper right", bbox_to_anchor=(1.3, 1.1))
    ax.set_title("Multi-metric comparison (baselines: published values; *IntelliNav3D: trial collisions)", fontsize=7)
    return _save(fig, out_dir, "Fig11_radar.png")


def fig12(ours_by_room, out_dir):
    """ours_by_room: {room_label: {'out': .., 'walk': .., 'fid': ..}}"""
    rooms = ["Bedroom", "Living room", "Dining room"]
    t3 = {n.split(" [")[0]: v for n, _, v in P.TABLE3_FID}
    t4 = {n.split(" [")[0]: v for n, _, v in P.TABLE4}
    methods = ["ATISS", "DiffuScene", "PhyScene", "SemLayoutDiff", "IntelliNav3D"]
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.6))
    panels = [("Objects out of room (%) ↓", lambda m, r: t4[m][r][0] if m in t4 else ours_by_room.get(r, {}).get("out")),
              ("Walkable space (%) ↑", lambda m, r: t4[m][r][1] if m in t4 else ours_by_room.get(r, {}).get("walk")),
              ("FID ↓", lambda m, r: t3[m].get(r) if m in t3 else ours_by_room.get(r, {}).get("fid"))]
    w = 0.16
    for ax, (lab, get) in zip(axes, panels):
        for k, m in enumerate(methods):
            vals = [get(m, r) for r in rooms]
            xs = np.arange(len(rooms)) + (k - 2) * w
            ax.bar(xs, [v if v is not None else 0 for v in vals], w, label=m)
        ax.set_xticks(range(len(rooms)))
        ax.set_xticklabels(rooms, fontsize=7)
        ax.set_title(lab, fontsize=8)
    axes[0].legend(fontsize=6)
    fig.suptitle("IntelliNav3D (this code) against published values on 3D-FRONT (Tables 3 and 4)", fontsize=8)
    return _save(fig, out_dir, "Fig12_comparison.png")
