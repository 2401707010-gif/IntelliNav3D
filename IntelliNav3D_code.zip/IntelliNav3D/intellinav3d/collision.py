"""Collision Map Generation and Furniture Clearance Module (Section 3.5, Eqs. 10-11)."""
import numpy as np
from scipy import ndimage

from .geometry import signed_gap
from .navigation import NavGrid
from .scene import is_functional


def pair_gaps(scene, robot_height=0.12):
    """Signed footprint gap g_ij (Eq. 10) for every pair of floor objects."""
    idx = scene.floor_object_indices(robot_height)
    corners = {i: scene.objects[i].corners() for i in idx}
    out = []
    for a in range(len(idx)):
        for b in range(a + 1, len(idx)):
            i, j = idx[a], idx[b]
            out.append((i, j, signed_gap(corners[i], corners[j])))
    return out


def clearance_required(scene, i, j, cfg_col):
    if is_functional(scene.objects[i].category, scene.objects[j].category):
        return cfg_col.functional_clearance
    return cfg_col.clearance


def collision_penalty(scene, cfg_col, robot_height=0.12, gaps=None):
    """CP = sum_{i<j} max(0, c_ij - g_ij) (Eq. 11). Also returns the per-pair terms."""
    gaps = gaps if gaps is not None else pair_gaps(scene, robot_height)
    terms = []
    for i, j, g in gaps:
        c = clearance_required(scene, i, j, cfg_col)
        t = max(0.0, c - g)
        if t > 0:
            terms.append((i, j, g, c, t))
    return float(sum(t[-1] for t in terms)), terms


def collision_map(scene, cfg, grid=None):
    """Collision map M on the navigation grid: 0 free, 1 occupied by one object,
    2 clearance violation (0 < g_ij < c_ij), 3 overlap of two or more footprints."""
    nav = grid or NavGrid(scene, cfg.navigation)
    M = np.zeros(nav.furn.shape, np.int8)
    M[nav.cover == 1] = 1
    M[nav.cover >= 2] = 3
    _, terms = collision_penalty(scene, cfg.collision, cfg.navigation.get("robot_height", 0.12))
    for i, j, g, c, t in terms:
        if g <= 0:
            continue
        # free cells lying in the gap between the two footprints
        ci, cj = scene.objects[i].corners(), scene.objects[j].corners()
        lo = np.minimum(ci.min(0), cj.min(0))
        hi = np.maximum(ci.max(0), cj.max(0))
        r0, c0 = nav.to_cell(lo)
        r1, c1 = nav.to_cell(hi)
        sub = (slice(r0, r1 + 1), slice(c0, c1 + 1))
        mi = nav.footprint_mask(ci)[sub]
        mj = nav.footprint_mask(cj)[sub]
        di = ndimage.distance_transform_edt(~mi) * nav.res
        dj = ndimage.distance_transform_edt(~mj) * nav.res
        gapcells = (~mi) & (~mj) & (di + dj <= g + 2 * nav.res) & nav.inroom[sub]
        M[sub][gapcells & (M[sub] == 0)] = 2
    M[~nav.inroom] = 0
    return M, nav
