"""Multi-Objective Navigation Fitness Function (Sections 3.6-3.7, Eq. 13).

MONFF = w1*NS + w2*C_s + w3*A_s + w4*SC + w5*HC - lambda*CP   (a weighted-sum scalarisation)
"""
import numpy as np

from .collision import collision_penalty
from .graph import pair_key
from .navigation import NavGrid, human_comfort, navigation_metrics


def spatial_consistency(scene, stats):
    """SC = 1 - normalised mean deviation of pairwise object distances from training statistics.
    Deviation of a pair = |d - mu| / mu (clipped to 1), mu = training mean for that category pair."""
    objs = scene.objects
    devs = []
    for i in range(len(objs)):
        for j in range(i + 1, len(objs)):
            p = stats["pairs"].get(pair_key(objs[i].category, objs[j].category))
            if p is None:
                continue
            d = np.hypot(objs[i].x - objs[j].x, objs[i].y - objs[j].y)
            devs.append(min(1.0, abs(d - p["mean"]) / max(p["mean"], 0.1)))
    return float(1.0 - np.mean(devs)) if devs else 1.0


def monff_value(c, cfg_monff):
    w = cfg_monff.weights
    return float(w[0] * c["NS"] + w[1] * c["C_s"] + w[2] * c["A_s"] + w[3] * c["SC"] + w[4] * c["HC"]
                 - cfg_monff.collision_lambda * c["CP"])


def evaluate_layout(scene, cfg, stats, pairs, planner="dijkstra", reward_mode="monff", empty=None):
    """All MONFF components of a layout. reward_mode='ans' gives the 'without MONFF' ablation score."""
    nav_cfg = cfg.navigation
    grid = NavGrid(scene, nav_cfg)
    empty = empty or NavGrid(scene, nav_cfg, empty=True)
    nm = navigation_metrics(scene, nav_cfg, pairs, planner=planner, grid=grid, empty_grid=empty)
    hc = human_comfort(scene, nav_cfg, cfg.monff.comfort_distance, grid=grid)
    cp, _ = collision_penalty(scene, cfg.collision, nav_cfg.get("robot_height", 0.12))
    sc = spatial_consistency(scene, stats)
    comp = {"NS": nm["ANS"], "P_s": nm["P_s"], "C_s": nm["C_s"], "A_s": nm["A_s"], "SC": sc, "HC": hc, "CP": cp}
    comp["MONFF"] = monff_value(comp, cfg.monff)
    comp["score"] = comp["MONFF"] if reward_mode == "monff" else comp["NS"]
    return comp
