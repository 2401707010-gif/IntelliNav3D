"""The illustrative 4.0 m x 3.6 m bedroom used in Sections 3.2-3.5 (Figs. 3, 5, 6 and 7).

`defects=True` gives the diffusion output described in Section 3.3: the wardrobe 0.12 m from the bed,
the chair 0.045 m into the desk and the right nightstand 0.025 m into the bed frame (CP = 0.300 m).
`defects=False` gives the corrected layout of Fig. 7(b) (CP = 0).
"""
import math

from .scene import Obj, Opening, Scene, assign_supports


def example_bedroom(defects=False):
    W, H = 4.0, 3.6
    bed = Obj("bed", 2.0, 2.6, math.pi, 1.6, 2.0, 0.55)
    ns_l = Obj("nightstand", 0.95, 3.35, math.pi, 0.45, 0.4, 0.55)
    ns_r = Obj("nightstand", 3.0 if defects else 3.05, 3.35, math.pi, 0.45, 0.4, 0.55)
    if defects:
        # wardrobe gap to the bed footprint 0.12 m, centres 1.64 m apart
        ward = Obj("wardrobe", 3.22, 2.6 - math.sqrt(1.64 ** 2 - 1.22 ** 2), math.pi / 2, 1.2, 0.6, 2.1)
    else:
        ward = Obj("wardrobe", 3.7, 1.03, math.pi / 2, 1.2, 0.6, 2.1)
    desk = Obj("desk", 0.3, 1.0, -math.pi / 2, 1.1, 0.55, 0.75)
    chair = Obj("chair", 0.755 if defects else 0.825, 1.0, -math.pi / 2, 0.45, 0.45, 0.9)
    dresser = Obj("dresser", 2.0, 0.25, 0.0, 1.0, 0.45, 0.8)
    lamp = Obj("table_lamp", ns_r.x, ns_r.y, 0.0, 0.25, 0.25, 0.45, z=0.55)
    sc = Scene("example_bedroom" + ("_generated" if defects else "_corrected"), "example", "bedroom",
               [[0, 0], [W, 0], [W, H], [0, H]], [bed, ns_l, ns_r, ward, desk, chair, dresser, lamp],
               [Opening([3.4, 0.0], 0.9, [0.0, 1.0], "door")])
    return assign_supports(sc)
