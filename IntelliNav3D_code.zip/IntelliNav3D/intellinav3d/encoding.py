"""Conversion between Scene objects and fixed-size arrays for the neural modules (numpy only)."""
import numpy as np

from .geometry import points_in_polygon, wrap_angle
from .graph import EDGE_DIM, build_graph, node_features, template_graph
from .scene import ROOM2ID, Scene


def frame(scene):
    """Normalisation frame: centre of the floor bounding box and the half of its largest extent."""
    lo, hi = scene.bounds()
    c = (lo + hi) / 2
    s = float(max((hi - lo).max() / 2, 0.5))
    return c, s


def floor_mask(scene, res=64, fr=None):
    c, s = fr or frame(scene)
    g = (np.arange(res) + 0.5) / res * 2 - 1
    X, Y = np.meshgrid(g, g)
    pts = np.stack([X.ravel() * s + c[0], Y.ravel() * s + c[1]], 1)
    return points_in_polygon(pts, scene.floor_np).reshape(res, res).astype(np.float32)


def _pad(a, n, value=0):
    out = np.full((n,) + a.shape[1:], value, dtype=a.dtype)
    out[: len(a)] = a[:n]
    return out


def _pad2(a, n):
    out = np.zeros((n, n) + a.shape[2:], dtype=a.dtype)
    m = min(len(a), n)
    out[:m, :m] = a[:m, :m]
    return out


def encode_pose(scene, fr=None):
    c, s = fr or frame(scene)
    return np.array([[(o.x - c[0]) / s, (o.y - c[1]) / s, np.cos(o.theta), np.sin(o.theta)]
                     for o in scene.objects], np.float32).reshape(-1, 4)


def encode_scene(scene, max_n, stats, thr, mask_res=64, nav_cond=(0.0, 0.0), real_graph=False):
    """Arrays used by the GAT, the denoiser and the PPO policy."""
    fr = frame(scene)
    n = len(scene.objects)
    cats, feats = node_features(scene)
    if real_graph:
        adj, rel, ef = build_graph(scene, thr)
    else:
        adj, rel, ef = template_graph([o.category for o in scene.objects], [o.parent for o in scene.objects], stats, thr)
    return {
        "cats": _pad(cats, max_n), "feats": _pad(feats, max_n), "pose": _pad(encode_pose(scene, fr), max_n),
        "mask": _pad(np.ones(n, bool), max_n, False), "adj": _pad2(adj, max_n), "rel": _pad2(rel, max_n),
        "ef": _pad2(ef, max_n), "room": np.int64(ROOM2ID.get(scene.room_type, 0)),
        "floor": floor_mask(scene, mask_res, fr)[None], "nav": np.asarray(nav_cond, np.float32),
        "parent": _pad(np.array([o.parent for o in scene.objects], np.int64), max_n, -1),
    }


def real_graph_arrays(scene, max_n, thr):
    adj, rel, ef = build_graph(scene, thr)
    return _pad2(adj, max_n), _pad2(rel, max_n), _pad2(ef, max_n)


def decode_pose(scene_template: Scene, pose, fr=None):
    """Write generated poses (N x 4, normalised) back into a copy of the template scene."""
    c, s = fr or frame(scene_template)
    out = scene_template.copy()
    for i, o in enumerate(out.objects):
        o.x = float(c[0] + pose[i, 0] * s)
        o.y = float(c[1] + pose[i, 1] * s)
        o.theta = float(wrap_angle(np.arctan2(pose[i, 3], pose[i, 2])))
    for o in out.objects:                 # supported objects stand on their parent
        if o.parent >= 0:
            p = out.objects[o.parent]
            o.x, o.y = p.x, p.y
    return out


def augment(enc, k, flip):
    """Rotation by k*90 degrees and optional mirror about the y axis (applied to pose and floor mask)."""
    e = dict(enc)
    pose = e["pose"].copy()
    floor = e["floor"].copy()
    x, y, c, s = pose[:, 0].copy(), pose[:, 1].copy(), pose[:, 2].copy(), pose[:, 3].copy()
    th = np.arctan2(s, c)
    if flip:
        x = -x
        th = np.pi - th
        floor = floor[:, :, ::-1]
    for _ in range(k % 4):
        x, y = -y, x
        th = th + np.pi / 2
        floor = np.rot90(floor, -1, axes=(1, 2))   # counter-clockwise in the y-up frame
    pose[:, 0], pose[:, 1], pose[:, 2], pose[:, 3] = x, y, np.cos(th), np.sin(th)
    pose[~e["mask"]] = 0
    e["pose"] = pose.astype(np.float32)
    e["floor"] = np.ascontiguousarray(floor)
    return e


__all__ = ["frame", "floor_mask", "encode_scene", "decode_pose", "augment", "real_graph_arrays", "EDGE_DIM"]
