"""Adaptive Navigation Module (Section 3.4, Algorithm 2) and the Human Comfort Score (Eq. 16).

Occupancy grid (5 cm) -> obstacle inflation by the robot radius -> 8-connected navigation graph ->
A* best paths between start-target pairs -> P_s, C_s, A_s and ANS.
"""
import heapq
import zlib

import numpy as np
from scipy import ndimage
from skimage.graph import MCP_Geometric

from .geometry import points_in_polygon, polygon_area

SQRT2 = float(np.sqrt(2.0))
_NB = [(-1, -1, SQRT2), (-1, 0, 1.0), (-1, 1, SQRT2), (0, -1, 1.0), (0, 1, 1.0), (1, -1, SQRT2), (1, 0, 1.0), (1, 1, SQRT2)]
EIGHT = np.ones((3, 3), int)


class NavGrid:
    """Occupancy grid of one room. Index convention: grid[row, col] with row ~ y, col ~ x."""

    def __init__(self, scene, nav_cfg, empty=False, cell_size=None):
        self.res = float(cell_size or nav_cfg.cell_size)
        self.r = float(nav_cfg.robot_radius)
        floor = scene.floor_np
        self.lo = floor.min(0) - 2 * self.res
        hi = floor.max(0) + 2 * self.res
        self.nx = int(np.ceil((hi[0] - self.lo[0]) / self.res))
        self.ny = int(np.ceil((hi[1] - self.lo[1]) / self.res))
        xs = self.lo[0] + (np.arange(self.nx) + 0.5) * self.res
        ys = self.lo[1] + (np.arange(self.ny) + 0.5) * self.res
        X, Y = np.meshgrid(xs, ys)
        self.centres = np.stack([X, Y], -1)
        self.inroom = points_in_polygon(self.centres.reshape(-1, 2), floor).reshape(self.ny, self.nx)
        self.room_area = polygon_area(floor)
        self.furn = np.zeros((self.ny, self.nx), bool)
        self.owner = -np.ones((self.ny, self.nx), np.int32)     # last object covering a cell
        self.cover = np.zeros((self.ny, self.nx), np.int16)     # number of footprints covering a cell
        if not empty:
            for i in scene.floor_object_indices(nav_cfg.get("robot_height", 0.12)):
                m = self.footprint_mask(scene.objects[i].corners())
                self.furn |= m
                self.cover += m
                self.owner[m] = i
        self.occupied = (~self.inroom) | self.furn
        # distance from each cell centre to the nearest obstacle boundary (metres)
        self.dist = np.maximum(ndimage.distance_transform_edt(~self.occupied) * self.res - self.res / 2, 0.0)
        self.dist[self.occupied] = 0.0
        self.navigable = (self.dist > self.r) & self.inroom          # Step 2: inflation
        if self.furn.any():
            fd = ndimage.distance_transform_edt(~self.furn) * self.res - self.res / 2
        else:
            fd = np.full(self.furn.shape, np.inf)
        self.furn_dist = np.maximum(fd, 0.0)

    # ---------------- coordinates ----------------
    def footprint_mask(self, corners):
        m = np.zeros((self.ny, self.nx), bool)
        lo = np.floor((corners.min(0) - self.lo) / self.res).astype(int)
        hi = np.ceil((corners.max(0) - self.lo) / self.res).astype(int)
        c0, r0 = max(lo[0], 0), max(lo[1], 0)
        c1, r1 = min(hi[0] + 1, self.nx), min(hi[1] + 1, self.ny)
        if c1 <= c0 or r1 <= r0:
            return m
        sub = self.centres[r0:r1, c0:c1].reshape(-1, 2)
        m[r0:r1, c0:c1] = points_in_polygon(sub, corners).reshape(r1 - r0, c1 - c0)
        return m

    def to_cell(self, p):
        c = int(np.clip((p[0] - self.lo[0]) / self.res, 0, self.nx - 1))
        r = int(np.clip((p[1] - self.lo[1]) / self.res, 0, self.ny - 1))
        return r, c

    def to_world(self, rc):
        r, c = rc
        return np.array([self.lo[0] + (c + 0.5) * self.res, self.lo[1] + (r + 0.5) * self.res])

    def clearance_at(self, xy):
        """Bilinear interpolation of the obstacle-distance field at continuous points (N x 2)."""
        xy = np.atleast_2d(xy)
        fx = (xy[:, 0] - self.lo[0]) / self.res - 0.5
        fy = (xy[:, 1] - self.lo[1]) / self.res - 0.5
        x0 = np.clip(np.floor(fx).astype(int), 0, self.nx - 2)
        y0 = np.clip(np.floor(fy).astype(int), 0, self.ny - 2)
        tx = np.clip(fx - x0, 0, 1)
        ty = np.clip(fy - y0, 0, 1)
        d = self.dist
        v = (d[y0, x0] * (1 - tx) * (1 - ty) + d[y0, x0 + 1] * tx * (1 - ty)
             + d[y0 + 1, x0] * (1 - tx) * ty + d[y0 + 1, x0 + 1] * tx * ty)
        return v

    def snap(self, rc, radius):
        """Nearest navigable cell within `radius` metres (None if there is none)."""
        r, c = rc
        if self.navigable[r, c]:
            return rc
        k = int(np.ceil(radius / self.res))
        r0, r1 = max(r - k, 0), min(r + k + 1, self.ny)
        c0, c1 = max(c - k, 0), min(c + k + 1, self.nx)
        sub = self.navigable[r0:r1, c0:c1]
        if not sub.any():
            return None
        rr, cc = np.nonzero(sub)
        d = (rr + r0 - r) ** 2 + (cc + c0 - c) ** 2
        i = int(np.argmin(d))
        if np.sqrt(d[i]) * self.res > radius:
            return None
        return int(rr[i] + r0), int(cc[i] + c0)


# --------------------------------------------------------------------------------------
# path search
# --------------------------------------------------------------------------------------
def astar(nav, start, goal):
    """A* on the 8-connected navigation graph (Algorithm 2, Step 4), heuristic = Euclidean distance.
    Returns (length in metres, list of (row, col)) or (inf, None)."""
    if start is None or goal is None:
        return np.inf, None
    if not (nav[start] and nav[goal]):
        return np.inf, None
    ny, nx = nav.shape
    gr, gc = goal
    g = {start: 0.0}
    parent = {start: None}
    openh = [(np.hypot(start[0] - gr, start[1] - gc), 0.0, start)]
    closed = set()
    while openh:
        _, gcost, cur = heapq.heappop(openh)
        if cur in closed:
            continue
        if cur == goal:
            path = []
            while cur is not None:
                path.append(cur)
                cur = parent[cur]
            return gcost, path[::-1]
        closed.add(cur)
        r, c = cur
        for dr, dc, w in _NB:
            rr, cc = r + dr, c + dc
            if rr < 0 or cc < 0 or rr >= ny or cc >= nx or not nav[rr, cc]:
                continue
            nb = (rr, cc)
            ng = gcost + w
            if ng < g.get(nb, np.inf):
                g[nb] = ng
                parent[nb] = cur
                heapq.heappush(openh, (ng + np.hypot(rr - gr, cc - gc), ng, nb))
    return np.inf, None


def dijkstra_lengths(nav, start, goals):
    """Optimal path lengths from one start to several goals (same graph and edge costs as astar,
    hence identical lengths). Uses the compiled MCP solver for speed (PPO training)."""
    if start is None or not nav[start]:
        return [np.inf] * len(goals), None
    cost = np.where(nav, 1.0, np.inf)
    m = MCP_Geometric(cost, fully_connected=True)
    cum, _ = m.find_costs([start])
    out = []
    for gl in goals:
        out.append(float(cum[gl]) if gl is not None and np.isfinite(cum[gl]) else np.inf)
    return out, m


def path_length_cells(path):
    if not path:
        return np.inf
    p = np.asarray(path, float)
    return float(np.sum(np.linalg.norm(np.diff(p, axis=0), axis=1)))


# --------------------------------------------------------------------------------------
# start-target pairs (identical for every method, Section 4.1.2)
# --------------------------------------------------------------------------------------
def sample_pairs(scene, nav_cfg, k=None, min_dist=None):
    k = k or nav_cfg.pairs_per_scene
    min_dist = nav_cfg.min_pair_distance if min_dist is None else min_dist
    empty = NavGrid(scene, nav_cfg, empty=True)
    rng = np.random.default_rng(zlib.crc32(scene.scene_id.encode()))
    lab, n = ndimage.label(empty.navigable, structure=EIGHT)
    if n == 0:
        return []
    big = np.argmax(np.bincount(lab.ravel())[1:]) + 1
    cells = np.argwhere(lab == big)
    pts = cells[:, ::-1] * empty.res + empty.lo + empty.res / 2
    pairs = []
    span = np.max(np.linalg.norm(pts - pts.mean(0), axis=1)) * 2
    md = min(min_dist, 0.6 * span)
    for _ in range(k):
        for _attempt in range(200):
            a = pts[rng.integers(len(pts))]
            d = np.linalg.norm(pts - a, axis=1)
            cand = np.nonzero(d >= md)[0]
            if len(cand):
                b = pts[cand[rng.integers(len(cand))]]
                pairs.append((a.tolist(), b.tolist()))
                break
    return pairs


# --------------------------------------------------------------------------------------
# navigation metrics (Algorithm 2, Step 5) and Human Comfort (Eq. 16)
# --------------------------------------------------------------------------------------
def navigation_metrics(scene, nav_cfg, pairs, planner="astar", grid=None, empty_grid=None, return_paths=False):
    nav = grid or NavGrid(scene, nav_cfg)
    emp = empty_grid or NavGrid(scene, nav_cfg, empty=True)
    snap = nav_cfg.get("snap_radius", 0.5)
    d_max = nav_cfg.d_max
    ps, cs, paths, lengths = [], [], [], []
    queries = []
    for s, g in pairs:
        queries.append((nav.snap(nav.to_cell(s), snap), nav.snap(nav.to_cell(g), snap),
                        emp.snap(emp.to_cell(s), snap), emp.snap(emp.to_cell(g), snap)))
    if planner == "astar":
        res = [astar(nav.navigable, q[0], q[1]) for q in queries]
    else:
        res = []
        by_start = {}
        for qi, q in enumerate(queries):
            by_start.setdefault(q[0], []).append(qi)
        res = [None] * len(queries)
        for st, idx in by_start.items():
            lens, m = dijkstra_lengths(nav.navigable, st, [queries[i][1] for i in idx])
            for i, L in zip(idx, lens):
                path = None
                if np.isfinite(L) and m is not None:
                    path = [tuple(p) for p in m.traceback(queries[i][1])]
                res[i] = (L, path)
    for q, (L, path) in zip(queries, res):
        Lopt, _ = astar(emp.navigable, q[2], q[3]) if planner == "astar" else \
            (dijkstra_lengths(emp.navigable, q[2], [q[3]])[0][0], None)
        if path is None or not np.isfinite(L) or not np.isfinite(Lopt):
            ps.append(0.0)
            cs.append(0.0)
            paths.append(None)
            lengths.append(np.inf)
            continue
        ps.append(min(1.0, Lopt / max(L, 1e-9)))
        cl = np.array([nav.dist[p] for p in path])
        cs.append(float(np.mean(np.minimum(1.0, cl / d_max))))
        paths.append(path)
        lengths.append(L * nav.res)
    # accessibility: share of navigable cells reachable from the first start (BFS = connected component)
    a_s = 0.0
    if queries and queries[0][0] is not None and nav.navigable.any():
        lab, _ = ndimage.label(nav.navigable, structure=EIGHT)
        comp = lab[queries[0][0]]
        a_s = float((lab == comp).sum() / nav.navigable.sum())
    p_s = float(np.mean(ps)) if ps else 0.0
    c_s = float(np.mean(cs)) if cs else 0.0
    w = nav_cfg.ans_weights
    out = {"P_s": p_s, "C_s": c_s, "A_s": a_s, "ANS": float(w[0] * p_s + w[1] * c_s + w[2] * a_s),
           "path_lengths": lengths, "queries": queries}
    if return_paths:
        out["paths"] = paths
        out["grid"] = nav
    return out


def human_comfort(scene, nav_cfg, d_c=0.6, grid=None):
    """HC = A_usable / A_room (Eq. 16): free floor cells at least d_c from any furniture footprint,
    restricted to the largest connected walkable region."""
    nav = grid or NavGrid(scene, nav_cfg)
    usable = nav.inroom & (~nav.furn) & (nav.furn_dist >= d_c)
    if not usable.any():
        return 0.0
    lab, n = ndimage.label(usable, structure=EIGHT)
    largest = np.bincount(lab.ravel())[1:].max()
    return float(min(1.0, largest * nav.res ** 2 / nav.room_area))
