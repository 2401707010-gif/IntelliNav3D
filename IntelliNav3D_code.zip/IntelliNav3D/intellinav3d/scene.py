"""Scene representation used throughout the code.

A scene is one room: a floor polygon (metres, floor plane x-y), doors/windows on its walls,
and a list of furniture objects with oriented 3-D boxes.
"""
import copy
import json
from dataclasses import asdict, dataclass, field
from typing import List

import numpy as np

from .geometry import obb_corners, points_in_polygon

# Unified object categories (3D-FUTURE categories are mapped to these in data/front3d.py).
CATEGORIES = [
    "bed", "kids_bed", "nightstand", "wardrobe", "dresser", "dressing_table", "desk", "chair",
    "armchair", "sofa", "coffee_table", "side_table", "tv_stand", "bookshelf", "shelf", "cabinet",
    "children_cabinet", "wine_cabinet", "console_table", "dining_table", "dining_chair", "stool",
    "table_lamp", "floor_lamp", "pendant_lamp", "ceiling_lamp", "kitchen_cabinet", "refrigerator",
    "table", "other",
]
CAT2ID = {c: i for i, c in enumerate(CATEGORIES)}
ROOM_TYPES = ["bedroom", "livingroom", "diningroom", "kitchen"]
ROOM2ID = {r: i for i, r in enumerate(ROOM_TYPES)}

# Functional pairs (Section 3.5: c_ij = 0, and "functional" edges in the scene graph, Section 3.2)
FUNCTIONAL_PAIRS = {
    frozenset(p) for p in [
        ("bed", "nightstand"), ("kids_bed", "nightstand"), ("desk", "chair"), ("dressing_table", "chair"),
        ("dressing_table", "stool"), ("dining_table", "dining_chair"), ("dining_table", "stool"),
        ("dining_table", "chair"), ("sofa", "coffee_table"), ("sofa", "side_table"),
        ("armchair", "side_table"), ("armchair", "coffee_table"), ("table", "chair"),
        ("table", "dining_chair"), ("desk", "stool"),
    ]
}
SUPPORT_CATEGORIES = {"table_lamp"}          # objects that normally stand on another object
CEILING_CATEGORIES = {"pendant_lamp", "ceiling_lamp"}


def is_functional(c1, c2):
    return frozenset((c1, c2)) in FUNCTIONAL_PAIRS


@dataclass
class Obj:
    category: str
    x: float
    y: float
    theta: float
    w: float           # width (local x)
    d: float           # depth (local y)
    h: float           # height
    z: float = 0.0     # bottom height above floor
    parent: int = -1   # index of supporting object (-1 = stands on the floor)
    jid: str = ""      # 3D-FUTURE model id (for textured rendering)

    def corners(self):
        return obb_corners(self.x, self.y, self.w, self.d, self.theta)


@dataclass
class Opening:
    center: List[float]
    width: float
    normal: List[float]    # unit vector pointing into the room
    kind: str = "door"     # door | window


@dataclass
class Scene:
    scene_id: str
    house_id: str
    room_type: str
    floor: List[List[float]]
    objects: List[Obj] = field(default_factory=list)
    openings: List[Opening] = field(default_factory=list)

    # ---------------- io ----------------
    def to_dict(self):
        return {
            "scene_id": self.scene_id, "house_id": self.house_id, "room_type": self.room_type,
            "floor": [list(map(float, p)) for p in self.floor],
            "objects": [asdict(o) for o in self.objects],
            "openings": [asdict(o) for o in self.openings],
        }

    @staticmethod
    def from_dict(d):
        return Scene(
            scene_id=d["scene_id"], house_id=d.get("house_id", d["scene_id"]), room_type=d["room_type"],
            floor=[list(p) for p in d["floor"]],
            objects=[Obj(**o) for o in d.get("objects", [])],
            openings=[Opening(**o) for o in d.get("openings", [])],
        )

    def save(self, path):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f)

    @staticmethod
    def load(path):
        with open(path) as f:
            return Scene.from_dict(json.load(f))

    def copy(self):
        return copy.deepcopy(self)

    # ---------------- helpers ----------------
    @property
    def floor_np(self):
        return np.asarray(self.floor, dtype=float)

    def bounds(self):
        f = self.floor_np
        return f.min(0), f.max(0)

    def floor_object_indices(self, robot_height=0.12):
        """Objects that stand on the floor and block a ground robot (Section 3.5 footprints)."""
        out = []
        for i, o in enumerate(self.objects):
            if o.parent >= 0 or o.category in CEILING_CATEGORIES:
                continue
            if o.z > robot_height:          # wall cabinets, shelves mounted above the robot
                continue
            out.append(i)
        return out

    def doors(self):
        return [o for o in self.openings if o.kind == "door"]

    def windows(self):
        return [o for o in self.openings if o.kind == "window"]


def keepout_region(op: Opening, depth=0.5):
    """Rectangle of depth `depth` in front of a door or window (Section 3.8 (iii))."""
    c = np.asarray(op.center, float)
    n = np.asarray(op.normal, float)
    n = n / (np.linalg.norm(n) + 1e-12)
    t = np.array([-n[1], n[0]])
    hw = op.width / 2.0
    return np.array([c - t * hw, c + t * hw, c + t * hw + n * depth, c - t * hw + n * depth])


def assign_supports(scene: Scene, tol=0.12):
    """Detect objects resting on another object (e.g. a lamp on a nightstand) and set .parent."""
    objs = scene.objects
    for i, o in enumerate(objs):
        o.parent = -1
        if o.z < 0.25:
            continue
        best, bj = np.inf, -1
        for j, p in enumerate(objs):
            if j == i or p.z > 0.25:
                continue
            top = p.z + p.h
            if abs(top - o.z) < tol and points_in_polygon(np.array([[o.x, o.y]]), p.corners())[0]:
                if abs(top - o.z) < best:
                    best, bj = abs(top - o.z), j
        o.parent = bj
    return scene
