"""2-D geometry on the floor plane: oriented boxes (furniture footprints) and room polygons.

Only numpy/matplotlib are used, so no compiled geometry library is required.
"""
import numpy as np
from matplotlib.path import Path


def obb_corners(x, y, w, d, theta):
    """Corners (4x2, counter-clockwise) of a footprint centred at (x, y) with width w along the
    object's local x axis, depth d along its local y axis, rotated by theta (radians)."""
    c, s = np.cos(theta), np.sin(theta)
    hw, hd = w / 2.0, d / 2.0
    local = np.array([[-hw, -hd], [hw, -hd], [hw, hd], [-hw, hd]])
    R = np.array([[c, -s], [s, c]])
    return local @ R.T + np.array([x, y])


def polygon_area(poly):
    p = np.asarray(poly, dtype=float)
    x, y = p[:, 0], p[:, 1]
    return 0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


def points_in_polygon(points, poly):
    if len(points) == 0:
        return np.zeros(0, dtype=bool)
    return Path(np.asarray(poly)).contains_points(np.asarray(points))


def _axes(c):
    e = np.roll(c, -1, axis=0) - c
    n = np.stack([-e[:, 1], e[:, 0]], 1)
    return n / (np.linalg.norm(n, axis=1, keepdims=True) + 1e-12)


def sat_penetration(c1, c2):
    """Separating-axis test for two convex polygons.
    Returns (overlapping, penetration_depth). Depth = minimum overlap over all axes."""
    depth = np.inf
    for ax in np.vstack([_axes(c1), _axes(c2)]):
        p1, p2 = c1 @ ax, c2 @ ax
        ov = min(p1.max(), p2.max()) - max(p1.min(), p2.min())
        if ov <= 0:
            return False, 0.0
        depth = min(depth, ov)
    return True, float(depth)


def _point_segment_dist(p, a, b):
    ab = b - a
    t = np.clip(np.dot(p - a, ab) / (np.dot(ab, ab) + 1e-12), 0.0, 1.0)
    return float(np.linalg.norm(p - (a + t * ab)))


def polygon_distance(c1, c2):
    """Minimum Euclidean distance between two non-intersecting convex polygons."""
    best = np.inf
    for P, Q in ((c1, c2), (c2, c1)):
        for p in P:
            for i in range(len(Q)):
                best = min(best, _point_segment_dist(p, Q[i], Q[(i + 1) % len(Q)]))
    return best


def signed_gap(c1, c2):
    """Signed footprint gap g_ij of Eq. (10): distance if disjoint, -penetration depth if overlapping."""
    ov, depth = sat_penetration(c1, c2)
    if ov:
        return -depth
    return polygon_distance(c1, c2)


def _seg_intersect(p1, p2, q1, q2):
    def orient(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])

    d1, d2 = orient(q1, q2, p1), orient(q1, q2, p2)
    d3, d4 = orient(p1, p2, q1), orient(p1, p2, q2)
    return (d1 * d2 < 0) and (d3 * d4 < 0)


def sample_polygon(c, step=0.025):
    """Regular sample points inside a convex polygon (used for area fractions)."""
    lo, hi = c.min(0), c.max(0)
    xs = np.arange(lo[0] + step / 2, hi[0], step)
    ys = np.arange(lo[1] + step / 2, hi[1], step)
    if len(xs) == 0 or len(ys) == 0:
        return c.mean(0, keepdims=True)
    X, Y = np.meshgrid(xs, ys)
    pts = np.stack([X.ravel(), Y.ravel()], 1)
    inside = points_in_polygon(pts, c)
    pts = pts[inside]
    return pts if len(pts) else c.mean(0, keepdims=True)


def fraction_outside(c, poly, step=0.025):
    """Fraction of the footprint area that lies outside the room polygon."""
    pts = sample_polygon(c, step)
    return float(1.0 - points_in_polygon(pts, poly).mean())


def overlap_fraction(c, region, step=0.025):
    """Fraction of footprint c that lies inside convex region."""
    pts = sample_polygon(c, step)
    return float(points_in_polygon(pts, region).mean())


def overlap_area(c, region, step=0.025):
    return overlap_fraction(c, region, step) * polygon_area(c)


def rect_inside_polygon(c, poly):
    """True if a convex footprint lies completely inside a (possibly non-convex) polygon."""
    if not points_in_polygon(c, poly).all():
        return False
    poly = np.asarray(poly)
    # no polygon vertex strictly inside the footprint, no edge crossings
    if points_in_polygon(poly, c).any():
        return False
    for i in range(4):
        for j in range(len(poly)):
            if _seg_intersect(c[i], c[(i + 1) % 4], poly[j], poly[(j + 1) % len(poly)]):
                return False
    return True


def distance_to_polygon_boundary(c, poly):
    """Minimum distance from footprint corners/edges to the room boundary (walls)."""
    poly = np.asarray(poly)
    best = np.inf
    for p in c:
        for j in range(len(poly)):
            best = min(best, _point_segment_dist(p, poly[j], poly[(j + 1) % len(poly)]))
    for q in poly:
        for i in range(4):
            best = min(best, _point_segment_dist(q, c[i], c[(i + 1) % 4]))
    return best


def nearest_wall(c, poly):
    """Index of the nearest wall segment and its unit direction."""
    poly = np.asarray(poly)
    best, bj = np.inf, 0
    for j in range(len(poly)):
        a, b = poly[j], poly[(j + 1) % len(poly)]
        dmin = min(_point_segment_dist(p, a, b) for p in c)
        if dmin < best:
            best, bj = dmin, j
    a, b = poly[bj], poly[(bj + 1) % len(poly)]
    u = (b - a) / (np.linalg.norm(b - a) + 1e-12)
    return bj, u, best


def wrap_angle(a):
    return (a + np.pi) % (2 * np.pi) - np.pi
