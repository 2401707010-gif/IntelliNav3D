"""FID between rendered real and generated rooms (Section 4.8): Inception-v3 pool features via clean-fid,
1,000 generated vs 1,000 real test scenes, per room type and over all test rooms."""
import os
import random
import shutil

from .render import render_dir


def compute_fid(gen_dir, real_dir):
    from cleanfid import fid       # imported lazily: downloads Inception weights on first use
    return float(fid.compute_fid(gen_dir, real_dir, mode="clean", num_workers=0))


def _sample(files, n, seed):
    files = sorted(files)
    if len(files) <= n:
        return files
    rnd = random.Random(seed)
    return sorted(rnd.sample(files, n))


def fid_by_room(gen_scene_dir, real_scene_dir, test_ids_by_room, work_dir, n=1000, size=256, seed=0):
    """Returns {room_type: FID, ..., 'all': FID}."""
    out = {}
    groups = dict(test_ids_by_room)
    groups["all"] = [i for v in test_ids_by_room.values() for i in v]
    for rt, ids in groups.items():
        ids = _sample(ids, n, seed)
        gdir = os.path.join(work_dir, "gen", rt)
        rdir = os.path.join(work_dir, "real", rt)
        for d in (gdir, rdir):
            shutil.rmtree(d, ignore_errors=True)
        render_dir([os.path.join(gen_scene_dir, i + ".json") for i in ids
                    if os.path.exists(os.path.join(gen_scene_dir, i + ".json"))], gdir, size)
        render_dir([os.path.join(real_scene_dir, i + ".json") for i in ids], rdir, size)
        if len(os.listdir(gdir)) < 10:
            continue
        out[rt] = compute_fid(gdir, rdir)
    return out
