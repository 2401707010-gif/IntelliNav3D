"""Experiment orchestration: everything needed for Tables 3-15 (see README for the mapping)."""
import copy
import os


from .config import set_dotted
from .constraints import aggregate_plausibility, plausibility_counts
from .data.split import load_split, make_split
from .fid import fid_by_room
from .outputs import evaluate_output, read_json, write_json
from .scene import Scene


def _ids_by_room(cfg, ids, scenes_dir=None):
    out = {}
    for i in ids:
        rt = Scene.load(os.path.join(scenes_dir or cfg.paths.scenes_dir, i + ".json")).room_type
        out.setdefault(rt, []).append(i)
    return out


def fid_output(cfg, out, test_ids=None, real_dir=None):
    path = os.path.join(out, "fid.json")
    if os.path.exists(path):
        return read_json(path)
    real_dir = real_dir or cfg.paths.scenes_dir
    if test_ids is None:
        test_ids = load_split(cfg.paths.split_file)["test"]
    res = fid_by_room(os.path.join(out, "scenes"), real_dir, _ids_by_room(cfg, test_ids, real_dir),
                      os.path.join(out, "renders"), cfg.fid.n_samples, cfg.fid.image_size)
    write_json(res, path)
    return res


def plausibility_output(cfg, out):
    path = os.path.join(out, "plausibility.json")
    if os.path.exists(path):
        return read_json(path)
    pre_dir, sc_dir = os.path.join(out, "pre"), os.path.join(out, "scenes")
    counts_pre, counts_out = [], []
    for f in sorted(os.listdir(sc_dir)):
        if not f.endswith(".json"):
            continue
        ref = Scene.load(os.path.join(pre_dir, f))
        counts_pre.append(plausibility_counts(ref, ref, cfg))
        counts_out.append(plausibility_counts(ref, Scene.load(os.path.join(sc_dir, f)), cfg))
    res = {"before_ppo": aggregate_plausibility(counts_pre), "after_ppo": aggregate_plausibility(counts_out)}
    write_json(res, path)
    return res


def run_one(cfg, seed, variant, args, tag="main", test_dir=None, fid=True):
    from .pipeline import run_variant      # needs PyTorch
    out = run_variant(cfg, seed, variant, args.workers, args.n_envs, tag=tag, test_dir=test_dir)
    evaluate_output(cfg, out, args.workers, "scenes")
    evaluate_output(cfg, out, args.workers, "pre")
    plausibility_output(cfg, out)
    if fid:
        if test_dir:
            ids = [f[:-5] for f in os.listdir(test_dir) if f.endswith(".json")]
            fid_output(cfg, out, ids, test_dir)
        else:
            fid_output(cfg, out)
    return out


# ---------------------------------------------------------------------------------------------
def stage_main(cfg, args):
    for s in args.seeds:
        run_one(cfg, s, "full", args)


def stage_ablation(cfg, args):
    for v in ["no_gat", "no_ddpm", "no_ppo", "no_monff"]:
        for s in args.ablation_seeds:
            run_one(cfg, s, v, args)


def stage_plausibility(cfg, args):
    for s in args.ablation_seeds:
        run_one(cfg, s, "unconstrained", args, fid=False)


def weight_settings(base):
    out = [("equal", list(base))]
    for i in range(len(base)):
        for f in (1.2, 0.8):
            w = list(base)
            w[i] *= f
            tot = sum(w)
            out.append((f"w{i + 1}x{f}", [x / tot for x in w]))
    return out


def stage_sensitivity(cfg, args):
    for factor, values in cfg.experiments.sensitivity.items():
        if factor == "monff.weights":
            settings = weight_settings(cfg.monff.weights)
        else:
            settings = [(str(v), v) for v in values]
        for name, val in settings:
            c = copy.deepcopy(cfg)
            set_dotted(c, factor, val)
            if factor == "gat.hidden_dim" and c.gat.hidden_dim % c.gat.heads:
                continue
            tag = f"sens/{factor}={name}"
            for s in args.sensitivity_seeds:
                run_one(c, s, "full", args, tag=tag)


def stage_heldout(cfg, args):
    rt = cfg.experiments.heldout_room_type
    c = copy.deepcopy(cfg)
    c.paths.split_file = cfg.paths.split_file.replace(".json", f"_heldout_{rt}.json")
    c.paths.stats_file = cfg.paths.stats_file.replace(".json", f"_heldout_{rt}.json")
    if not os.path.exists(c.paths.split_file):
        make_split(c, out=c.paths.split_file, exclude_room_type=rt)
    for s in args.seeds:
        run_one(c, s, "full", args, tag=f"heldout_{rt}")


def stage_external(cfg, args):
    if not args.external_dir:
        print("no --external_dir given: independent-dataset row of Table 15 is skipped")
        return
    for s in args.seeds:
        run_one(cfg, s, "full", args, tag="external", test_dir=args.external_dir)


# ---------------------------------------------------------------------------------------------
def collect(cfg):
    """Gathers every metrics/fid/plausibility file into results/results.json."""
    root = os.path.join(cfg.paths.runs_dir, "outputs")
    res = {}
    for dirpath, dirnames, filenames in os.walk(root):
        if "done.json" not in filenames:
            continue
        rel = os.path.relpath(dirpath, root)
        parts = rel.split(os.sep)
        tag = "/".join(parts[:-2])
        variant, seed = parts[-2], int(parts[-1].replace("seed", ""))
        entry = {}
        for name in ("metrics_scenes", "metrics_pre", "fid", "plausibility"):
            p = os.path.join(dirpath, name + ".json")
            if os.path.exists(p):
                entry[name] = read_json(p)
        res.setdefault(tag, {}).setdefault(variant, {})[seed] = entry
    os.makedirs(cfg.paths.results_dir, exist_ok=True)
    write_json(res, os.path.join(cfg.paths.results_dir, "results.json"))
    return res
