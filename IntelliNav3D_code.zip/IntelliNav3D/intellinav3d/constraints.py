"""Physical and semantic constraints on PPO refinement (Section 3.8) and the plausibility statistics
of Table 13 (Section 4.9)."""
import numpy as np

from .geometry import (fraction_outside, nearest_wall, overlap_area, points_in_polygon,
                       rect_inside_polygon, wrap_angle)
from .scene import keepout_region


def _line_distance(c, a, u):
    """Minimum perpendicular distance of footprint corners to the infinite line through a along u."""
    n = np.array([-u[1], u[0]])
    return float(np.min(np.abs((c - a) @ n)))


class ConstraintChecker:
    def __init__(self, ref_scene, cfg, constrained=True):
        self.cfg = cfg
        self.ppo = cfg.ppo
        self.constrained = constrained
        self.rh = cfg.navigation.get("robot_height", 0.12)
        self.floor = ref_scene.floor_np
        self.keepouts = [keepout_region(op, self.ppo.door_keepout) for op in ref_scene.openings]
        self.children = {}
        for k, o in enumerate(ref_scene.objects):
            if o.parent >= 0:
                self.children.setdefault(o.parent, []).append(k)
        self.wall = {}
        for i in ref_scene.floor_object_indices(self.rh):
            o = ref_scene.objects[i]
            c = o.corners()
            j, u, dist = nearest_wall(c, self.floor)
            if dist <= self.ppo.wall_contact_distance:
                a = self.floor[j]
                self.wall[i] = {"a": a, "u": u, "d0": _line_distance(c, a, u), "theta0": o.theta}
        self.movable = [i for i, o in enumerate(ref_scene.objects) if o.parent < 0]

    def _move(self, scene, i, dx, dy, dth):
        s = scene.copy()
        o = s.objects[i]
        px, py = o.x, o.y
        o.x += dx
        o.y += dy
        o.theta = float(wrap_angle(o.theta + dth))
        c, sn = np.cos(dth), np.sin(dth)
        for k in self.children.get(i, []):
            ch = s.objects[k]
            rx, ry = ch.x - px, ch.y - py
            ch.x = o.x + c * rx - sn * ry
            ch.y = o.y + sn * rx + c * ry
            ch.theta = float(wrap_angle(ch.theta + dth))
        return s

    def clip_action(self, i, dx, dy, dth):
        n = np.hypot(dx, dy)
        if n > self.ppo.max_move:
            dx, dy = dx / n * self.ppo.max_move, dy / n * self.ppo.max_move
        lim = np.deg2rad(self.ppo.max_rotate_deg)
        dth = float(np.clip(dth, -lim, lim))
        if self.constrained and i in self.wall:          # (iv) keep wall contact and facing direction
            u = self.wall[i]["u"]
            t = dx * u[0] + dy * u[1]
            dx, dy, dth = t * u[0], t * u[1], 0.0
        return dx, dy, dth

    def apply(self, scene, i, dx, dy, dth):
        """Returns (new_scene, valid). Invalid actions leave the scene unchanged (Section 3.8 (vi))."""
        if i not in self.movable:
            return scene, False
        dx, dy, dth = self.clip_action(i, dx, dy, dth)
        new = self._move(scene, i, dx, dy, dth)
        if not self.constrained:
            return new, True
        o_old, o_new = scene.objects[i], new.objects[i]
        floor_obj = o_new.z <= self.rh
        if floor_obj:
            c_old, c_new = o_old.corners(), o_new.corners()
            # (ii) room boundary: footprint must not leave the room (or leave it further)
            if not rect_inside_polygon(c_new, self.floor):
                if rect_inside_polygon(c_old, self.floor):
                    return scene, False
                if fraction_outside(c_new, self.floor) > fraction_outside(c_old, self.floor) + 1e-6:
                    return scene, False
            # (iii) door / window keep-out regions
            for ko in self.keepouts:
                if overlap_area(c_new, ko) > overlap_area(c_old, ko) + 1e-6:
                    return scene, False
            # (iv) wall-aligned objects keep their contact distance within tolerance
            if i in self.wall:
                w = self.wall[i]
                if abs(_line_distance(c_new, w["a"], w["u"]) - w["d0"]) > self.ppo.wall_tolerance:
                    return scene, False
        return new, True


def plausibility_counts(ref, out, cfg):
    """Counts for Table 13. `ref` = diffusion output (before PPO), `out` = layout to assess."""
    rh = cfg.navigation.get("robot_height", 0.12)
    tol = cfg.ppo.wall_tolerance
    floor = out.floor_np
    fidx = out.floor_object_indices(rh)
    n_out = sum(fraction_outside(out.objects[i].corners(), floor) > 0.01 for i in fidx)
    doors = out.doors()
    blocked = 0
    for d in doors:
        ko = keepout_region(d, cfg.ppo.door_keepout)
        if any(overlap_area(out.objects[i].corners(), ko) > 0.01 for i in fidx):
            blocked += 1
    chk = ConstraintChecker(ref, cfg)
    n_rel, n_viol = 0, 0
    for i, w in chk.wall.items():
        n_rel += 1
        o = out.objects[i]
        moved_off = abs(_line_distance(o.corners(), w["a"], w["u"]) - w["d0"]) > tol
        turned = abs(wrap_angle(o.theta - w["theta0"])) > np.deg2rad(1.0)
        n_viol += int(moved_off or turned)
    for k, o in enumerate(out.objects):
        if o.parent >= 0:
            n_rel += 1
            p = out.objects[o.parent]
            n_viol += int(not points_in_polygon(np.array([[o.x, o.y]]), p.corners())[0])
    disp = [float(np.hypot(a.x - b.x, a.y - b.y)) for a, b in zip(ref.objects, out.objects)]
    return {"objects": len(fidx), "outside": int(n_out), "doors": len(doors), "doors_blocked": int(blocked),
            "relations": n_rel, "relation_violations": int(n_viol), "disp_sum": float(sum(disp)),
            "disp_n": len(disp)}


def aggregate_plausibility(counts):
    s = {k: sum(c[k] for c in counts) for k in counts[0]} if counts else {}
    if not s:
        return {}
    return {
        "objects_outside_pct": 100.0 * s["outside"] / max(s["objects"], 1),
        "doors_blocked_pct": 100.0 * s["doors_blocked"] / max(s["doors"], 1),
        "wall_support_violations_pct": 100.0 * s["relation_violations"] / max(s["relations"], 1),
        "mean_displacement_m": s["disp_sum"] / max(s["disp_n"], 1),
    }
