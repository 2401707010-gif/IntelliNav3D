"""Top-down orthographic renderings (256 x 256) with semantic-category colouring for FID (Section 4.8).

The manuscript renders with Blender 4.3 / Cycles; this renderer produces the semantic-colour variant of the
same view without Blender. scripts/render_blender.py gives the textured Blender alternative.
Real and generated scenes must always be rendered with the same renderer.
"""
import colorsys
import os

import numpy as np
from PIL import Image, ImageDraw

from .scene import CATEGORIES, Scene


def _palette():
    pal = {}
    len(CATEGORIES)
    for i, c in enumerate(CATEGORIES):
        r, g, b = colorsys.hsv_to_rgb((i * 0.618034) % 1.0, 0.65, 0.9)
        pal[c] = (int(r * 255), int(g * 255), int(b * 255))
    return pal


PALETTE = _palette()
FLOOR = (205, 205, 205)


def render_topdown(scene: Scene, size=256, margin=8):
    lo, hi = scene.bounds()
    c = (lo + hi) / 2
    s = (size - 2 * margin) / max((hi - lo).max(), 1e-6)

    def px(p):
        p = np.asarray(p, float)
        return [((x - c[0]) * s + size / 2, size / 2 - (y - c[1]) * s) for x, y in p]

    img = Image.new("RGB", (size, size), (255, 255, 255))
    d = ImageDraw.Draw(img)
    d.polygon(px(scene.floor), fill=FLOOR)
    order = sorted(range(len(scene.objects)), key=lambda i: scene.objects[i].z + scene.objects[i].h)
    for i in order:
        o = scene.objects[i]
        d.polygon(px(o.corners()), fill=PALETTE.get(o.category, (80, 80, 80)))
    return img


def render_dir(scene_dicts_or_paths, out_dir, size=256):
    os.makedirs(out_dir, exist_ok=True)
    for item in scene_dicts_or_paths:
        sc = Scene.load(item) if isinstance(item, str) else Scene.from_dict(item)
        render_topdown(sc, size).save(os.path.join(out_dir, sc.scene_id + ".png"))
