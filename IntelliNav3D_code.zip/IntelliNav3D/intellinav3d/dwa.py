"""Navigation trials (Section 4.1.2): A* global path + Dynamic Window Approach local control for a
circular differential-drive robot (radius 0.175 m, v_max 0.5 m/s, w_max 1 rad/s).

A trial succeeds if the robot comes within 10 cm of the goal within 500 control steps without a
collision. A collision is any contact between the robot footprint and a wall or furniture footprint.
"""
import numpy as np

from .navigation import astar


def _target_on_path(path_xy, pos, idx, lookahead):
    d = np.linalg.norm(path_xy[idx:] - pos, axis=1)
    j = idx + int(np.argmin(d))
    k = j
    while k < len(path_xy) - 1 and np.linalg.norm(path_xy[k] - pos) < lookahead:
        k += 1
    return path_xy[k], j


def run_trial(grid, start_cell, goal_cell, nav_cfg, path=None):
    cfg = nav_cfg.dwa
    r = nav_cfg.robot_radius
    if path is None:
        _, path = astar(grid.navigable, start_cell, goal_cell)
    if path is None:
        return {"success": False, "collision": False, "steps": 0, "reason": "no_path"}
    path_xy = np.array([grid.to_world(p) for p in path])
    goal = path_xy[-1]
    pos = path_xy[0].copy()
    first = path_xy[min(3, len(path_xy) - 1)]
    th = float(np.arctan2(first[1] - pos[1], first[0] - pos[0])) if len(path_xy) > 1 else 0.0
    v = w = 0.0
    dt, n_h = cfg.dt, max(1, int(round(cfg.horizon / cfg.dt)))
    vmax, wmax = nav_cfg.v_max, nav_cfg.w_max
    idx = 0
    for step in range(nav_cfg.max_steps):
        if np.linalg.norm(pos - goal) <= nav_cfg.goal_tolerance:
            return {"success": True, "collision": False, "steps": step, "reason": "goal"}
        target, idx = _target_on_path(path_xy, pos, idx, cfg.lookahead)
        vs = np.linspace(max(0.0, v - cfg.v_acc * dt), min(vmax, v + cfg.v_acc * dt), cfg.v_samples)
        ws = np.linspace(max(-wmax, w - cfg.w_acc * dt), min(wmax, w + cfg.w_acc * dt), cfg.w_samples)
        V, Wg = np.meshgrid(vs, ws)
        V, Wg = V.ravel(), Wg.ravel()
        # forward-simulate all candidate velocities (vectorised over samples and horizon)
        ths = th + np.outer(Wg, np.arange(1, n_h + 1) * dt)
        xs = pos[0] + np.cumsum(V[:, None] * np.cos(ths) * dt, axis=1)
        ys = pos[1] + np.cumsum(V[:, None] * np.sin(ths) * dt, axis=1)
        clear = grid.clearance_at(np.stack([xs.ravel(), ys.ravel()], 1)).reshape(xs.shape) - r
        minclear = clear.min(1)
        ok = minclear > 0.0
        if ok.any():
            end = np.stack([xs[:, -1], ys[:, -1]], 1)
            dgoal = np.linalg.norm(end - target, axis=1)
            head = np.abs(np.angle(np.exp(1j * (np.arctan2(target[1] - ys[:, -1], target[0] - xs[:, -1]) - ths[:, -1]))))
            # all terms normalised to [0, 1]
            cost = (cfg.w_goal * np.minimum(dgoal / cfg.lookahead, 2.0)
                    + cfg.w_head * head / np.pi
                    + cfg.w_clear * (1.0 - np.minimum(minclear, cfg.clear_ref) / cfg.clear_ref)
                    + cfg.w_speed * (vmax - V) / vmax)
            cost[~ok] = np.inf
            b = int(np.argmin(cost))
            v, w = float(V[b]), float(Wg[b])
        else:
            # no admissible forward motion: stop and turn in place towards the target
            v = 0.0
            ang = np.arctan2(target[1] - pos[1], target[0] - pos[0]) - th
            w = float(np.clip(np.angle(np.exp(1j * ang)) / dt, -wmax, wmax))
        th = th + w * dt
        pos = pos + v * dt * np.array([np.cos(th), np.sin(th)])
        if grid.clearance_at(pos[None])[0] < r - 1e-6:
            return {"success": False, "collision": True, "steps": step + 1, "reason": "collision"}
    return {"success": False, "collision": False, "steps": nav_cfg.max_steps, "reason": "timeout"}
