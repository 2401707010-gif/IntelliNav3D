"""Torch-free helpers shared by the pipeline, the experiment runner and the table/figure scripts."""
import json
import os

from .data.split import load_split
from .evaluate import aggregate, evaluate_scenes
from .graph import compute_train_stats, load_stats, save_stats
from .scene import Scene


def load_scenes(cfg, ids):
    return [Scene.load(os.path.join(cfg.paths.scenes_dir, i + ".json")) for i in ids]


def write_json(obj, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=1)


def read_json(path):
    with open(path) as f:
        return json.load(f)


def prepare_stats(cfg, split):
    if os.path.exists(cfg.paths.stats_file):
        return load_stats(cfg.paths.stats_file)
    stats = compute_train_stats(load_scenes(cfg, split["train"]))
    save_stats(stats, cfg.paths.stats_file)
    return stats


def evaluate_output(cfg, out, workers=8, subdir="scenes"):
    path = os.path.join(out, f"metrics_{subdir}.json")
    if os.path.exists(path):
        return read_json(path)
    split = load_split(cfg.paths.split_file)
    stats = prepare_stats(cfg, split)
    d = os.path.join(out, subdir)
    dicts = [read_json(os.path.join(d, f)) for f in sorted(os.listdir(d)) if f.endswith(".json")]
    recs = evaluate_scenes(dicts, cfg, stats, workers)
    agg = aggregate(recs)
    write_json(recs, os.path.join(out, f"records_{subdir}.json"))
    write_json(agg, path)
    return agg
