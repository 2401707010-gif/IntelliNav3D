"""Scene graphs (Section 3.2, Algorithm 1 Steps 1 and 3) and training-set pairwise statistics."""
import json
from collections import defaultdict

import numpy as np

from .geometry import wrap_angle
from .scene import CAT2ID, CATEGORIES, Scene, is_functional

REL = {"none": 0, "near": 1, "functional": 2, "support": 3}
EDGE_DIM = 2 + 1 + 3      # [distance, cos(theta_ij), sin(theta_ij)] + one-hot(near, functional, support)


def relation(scene: Scene, i, j, dist, thr):
    oi, oj = scene.objects[i], scene.objects[j]
    if oi.parent == j or oj.parent == i:
        return REL["support"]
    if oi.parent >= 0 or oj.parent >= 0:      # supported objects are linked only to their support
        return REL["none"]
    if is_functional(oi.category, oj.category):
        return REL["functional"]
    if dist < thr:
        return REL["near"]
    return REL["none"]


def edge_feature(dist, dtheta, rel):
    f = np.zeros(EDGE_DIM, np.float32)
    f[0] = dist
    f[1] = np.cos(dtheta)
    f[2] = np.sin(dtheta)
    if rel > 0:
        f[2 + rel] = 1.0
    return f


def build_graph(scene: Scene, thr=2.0):
    """Graph of Step 1 (Algorithm 1): nodes = objects; edges for support/functional relations and
    for pairs whose centroids are closer than `thr`. Returns (adj NxN bool, rel NxN int, efeat NxNxE)."""
    n = len(scene.objects)
    adj = np.zeros((n, n), bool)
    rel = np.zeros((n, n), np.int64)
    ef = np.zeros((n, n, EDGE_DIM), np.float32)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            oi, oj = scene.objects[i], scene.objects[j]
            dist = float(np.hypot(oi.x - oj.x, oi.y - oj.y))
            r = relation(scene, i, j, dist, thr)
            rel[i, j] = r
            ef[i, j] = edge_feature(dist, wrap_angle(oj.theta - oi.theta), r)
            adj[i, j] = r > 0
    return adj, rel, ef


def undirected_edges(adj):
    n = adj.shape[0]
    return [(i, j) for i in range(n) for j in range(i + 1, n) if adj[i, j] or adj[j, i]]


# --------------------------------------------------------------------------------------
# training-set statistics: pairwise-distance priors (spatial consistency SC, template graphs)
# --------------------------------------------------------------------------------------
def pair_key(a, b):
    return "|".join(sorted((a, b)))


def compute_train_stats(scenes):
    d = defaultdict(list)
    pos = defaultdict(list)       # per (room_type, category): normalised position, angle, wall distance
    for sc in scenes:
        lo, hi = sc.bounds()
        ext = np.maximum(hi - lo, 1e-6)
        objs = sc.objects
        for i in range(len(objs)):
            o = objs[i]
            pos[f"{sc.room_type}|{o.category}"].append(
                [float((o.x - lo[0]) / ext[0]), float((o.y - lo[1]) / ext[1]), float(o.theta)])
            for j in range(i + 1, len(objs)):
                d[pair_key(objs[i].category, objs[j].category)].append(
                    float(np.hypot(objs[i].x - objs[j].x, objs[i].y - objs[j].y)))
    all_d = [v for vs in d.values() for v in vs]
    stats = {
        "pairs": {k: {"mean": float(np.mean(v)), "std": float(np.std(v) + 1e-3), "n": len(v)}
                  for k, v in d.items() if len(v) >= 3},
        "global_mean": float(np.mean(all_d)) if all_d else 2.0,
        "positions": {k: v for k, v in pos.items()},
    }
    return stats


def save_stats(stats, path):
    with open(path, "w") as f:
        json.dump(stats, f)


def load_stats(path):
    with open(path) as f:
        return json.load(f)


def prior_distance(stats, a, b):
    p = stats["pairs"].get(pair_key(a, b))
    return p["mean"] if p else stats["global_mean"]


def template_graph(categories, parents, stats, thr=2.0):
    """Graph used to condition generation when object positions are not yet known: edge distances
    are the training-set mean distances of each category pair (see README)."""
    n = len(categories)
    adj = np.zeros((n, n), bool)
    rel = np.zeros((n, n), np.int64)
    ef = np.zeros((n, n, EDGE_DIM), np.float32)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            dist = prior_distance(stats, categories[i], categories[j])
            if parents[i] == j or parents[j] == i:
                r = REL["support"]
                dist = 0.0
            elif parents[i] >= 0 or parents[j] >= 0:
                r = REL["none"]
            elif is_functional(categories[i], categories[j]):
                r = REL["functional"]
            elif dist < thr:
                r = REL["near"]
            else:
                r = REL["none"]
            rel[i, j] = r
            adj[i, j] = r > 0
            ef[i, j] = edge_feature(dist, 0.0, r)
    return adj, rel, ef


def node_features(scene_or_list):
    """Category id and size features (w, d, h, z) of each node (Algorithm 1 Step 2)."""
    if isinstance(scene_or_list, Scene):
        items = [(o.category, o.w, o.d, o.h, o.z) for o in scene_or_list.objects]
    else:
        items = [tuple(x[:5]) for x in scene_or_list]
    cats = np.array([CAT2ID.get(c, CAT2ID["other"]) for c, *_ in items], np.int64)
    feats = np.array([[w, d, h, z] for _, w, d, h, z in items], np.float32)
    return cats, feats


__all__ = ["REL", "EDGE_DIM", "build_graph", "template_graph", "compute_train_stats", "node_features",
           "CATEGORIES", "prior_distance", "undirected_edges", "load_stats", "save_stats"]
