"""Evaluation protocol of Section 4.1.2: navigation trials, collision rate, accessibility, human comfort,
MONFF components, and object-level plausibility for a set of generated rooms."""
import json
import os
from collections import defaultdict
import multiprocessing as mp

import numpy as np

from .collision import collision_penalty, pair_gaps
from .dwa import run_trial
from .geometry import fraction_outside
from .monff import monff_value, spatial_consistency
from .navigation import NavGrid, human_comfort, navigation_metrics, sample_pairs
from .scene import Scene

_G = {}


def _init(cfg, stats):
    _G["cfg"], _G["stats"] = cfg, stats


def evaluate_scene(scene_dict, cfg=None, stats=None, run_trials=True, planner="astar"):
    cfg = cfg or _G["cfg"]
    stats = stats or _G["stats"]
    sc = Scene.from_dict(scene_dict)
    nav_cfg = cfg.navigation
    pairs = sample_pairs(sc, nav_cfg)
    grid = NavGrid(sc, nav_cfg)
    nm = navigation_metrics(sc, nav_cfg, pairs, planner=planner, grid=grid, return_paths=True)
    hc = human_comfort(sc, nav_cfg, cfg.monff.comfort_distance, grid=grid)
    gaps = pair_gaps(sc, nav_cfg.get("robot_height", 0.12))
    cp, _ = collision_penalty(sc, cfg.collision, gaps=gaps)
    scs = spatial_consistency(sc, stats)
    comp = {"NS": nm["ANS"], "C_s": nm["C_s"], "A_s": nm["A_s"], "SC": scs, "HC": hc, "CP": cp}
    rec = {"scene_id": sc.scene_id, "room_type": sc.room_type, "P_s": nm["P_s"], "C_s": nm["C_s"],
           "A_s": nm["A_s"], "ANS": nm["ANS"], "HC": hc, "SC": scs, "CP": cp, "MONFF": monff_value(comp, cfg.monff)}
    # object-level measures (comparable with the published values of Tables 4 and 7)
    fidx = sc.floor_object_indices(nav_cfg.get("robot_height", 0.12))
    floor = sc.floor_np
    rec["n_objects"] = len(fidx)
    rec["n_outside"] = int(sum(fraction_outside(sc.objects[i].corners(), floor) > 0.01 for i in fidx))
    overl = set()
    for i, j, g in gaps:
        if g < -0.01:
            overl.update((i, j))
    rec["n_overlapping"] = len(overl)
    trials = []
    if run_trials:
        for q, path in zip(nm["queries"], nm["paths"]):
            trials.append(run_trial(grid, q[0], q[1], nav_cfg, path=path))
    rec["n_trials"] = len(trials)
    rec["n_success"] = int(sum(t["success"] for t in trials))
    rec["n_collision"] = int(sum(t["collision"] for t in trials))
    return rec


def evaluate_scenes(scene_dicts, cfg, stats, workers=1, run_trials=True):
    if workers <= 1:
        return [evaluate_scene(d, cfg, stats, run_trials) for d in scene_dicts]
    with mp.get_context("spawn").Pool(workers, initializer=_init, initargs=(cfg, stats)) as pool:
        return pool.starmap(evaluate_scene, [(d, None, None, run_trials) for d in scene_dicts], chunksize=4)


def aggregate(records):
    """Per room type and over all test rooms (percentages as in the paper's tables)."""
    groups = defaultdict(list)
    for r in records:
        groups[r["room_type"]].append(r)
        groups["all"].append(r)
    out = {}
    for k, rs in groups.items():
        nt = sum(r["n_trials"] for r in rs)
        out[k] = {
            "n_scenes": len(rs),
            "navigation_success": 100.0 * sum(r["n_success"] for r in rs) / max(nt, 1),
            "collision_rate": 100.0 * sum(r["n_collision"] for r in rs) / max(nt, 1),
            "accessibility": 100.0 * float(np.mean([r["A_s"] for r in rs])),
            "human_comfort": 100.0 * float(np.mean([r["HC"] for r in rs])),
            "path_efficiency": float(np.mean([r["P_s"] for r in rs])),
            "collision_avoidance": float(np.mean([r["C_s"] for r in rs])),
            "accessibility_score": float(np.mean([r["A_s"] for r in rs])),
            "spatial_consistency": float(np.mean([r["SC"] for r in rs])),
            "human_comfort_score": float(np.mean([r["HC"] for r in rs])),
            "collision_penalty": float(np.mean([r["CP"] for r in rs])),
            "monff": float(np.mean([r["MONFF"] for r in rs])),
            "objects_out_of_room": 100.0 * sum(r["n_outside"] for r in rs) / max(sum(r["n_objects"] for r in rs), 1),
            "object_overlap_rate": 100.0 * sum(r["n_overlapping"] for r in rs) / max(sum(r["n_objects"] for r in rs), 1),
        }
    return out


def load_scene_dir(d, ids=None):
    files = sorted(f for f in os.listdir(d) if f.endswith(".json"))
    out = []
    for f in files:
        if ids is not None and f[:-5] not in ids:
            continue
        with open(os.path.join(d, f)) as fh:
            out.append(json.load(fh))
    return out
