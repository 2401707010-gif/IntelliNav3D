"""Training and generation pipeline of IntelliNav3D (Algorithm 3).

Every trained component is cached under runs/<component>/<key>/ where <key> is a hash of exactly the
configuration values that affect it. Re-running an experiment therefore re-uses finished components,
and the sensitivity study (Table 14) only retrains what a changed factor touches.
"""
import hashlib
import json
import os
import random
import time
import multiprocessing as mp

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from .config import get_dotted
from .data.split import load_split
from .encoding import augment, decode_pose, encode_scene, real_graph_arrays
from .heuristic import heuristic_layout
from .models.ddpm import Denoiser, GaussianDiffusion
from .models.gat import GAT
from .monff import evaluate_layout
from .navigation import human_comfort, navigation_metrics, sample_pairs
from .rl.env import RefineEnv
from .rl.ppo import Policy, ppo_train, refine
from .rl.vec_env import VecEnv
from .outputs import evaluate_output, prepare_stats, read_json, write_json  # noqa: F401
from .scene import Scene

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ----------------------------------------------------------------------------------------------
# utilities
# ----------------------------------------------------------------------------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def key_of(*parts):
    s = json.dumps(parts, sort_keys=True, default=str)
    return hashlib.sha1(s.encode()).hexdigest()[:12]


def sub(cfg, *keys):
    return {k: get_dotted(cfg, k) for k in keys}


def load_scenes(cfg, ids):
    return [Scene.load(os.path.join(cfg.paths.scenes_dir, i + ".json")) for i in ids]


def log_to(path):
    def _log(rec):
        line = json.dumps(rec) if not isinstance(rec, str) else rec
        print(line, flush=True)
        with open(path, "a") as f:
            f.write(line + "\n")
    return _log


# ----------------------------------------------------------------------------------------------
# statistics and navigation conditions of the training data
# ----------------------------------------------------------------------------------------------
def _nav_cond_one(args):
    d, cfg = args
    sc = Scene.from_dict(d)
    nm = navigation_metrics(sc, cfg.navigation, sample_pairs(sc, cfg.navigation), planner="dijkstra")
    return sc.scene_id, [nm["ANS"], human_comfort(sc, cfg.navigation, cfg.monff.comfort_distance)]


def prepare_nav_cond(cfg, split, workers=8):
    path = cfg.paths.stats_file.replace(".json", "_navcond.json")
    if os.path.exists(path):
        return read_json(path)
    ids = split["train"] + split["val"]
    dicts = [s.to_dict() for s in load_scenes(cfg, ids)]
    with mp.get_context("spawn").Pool(workers) as pool:
        res = pool.map(_nav_cond_one, [(d, cfg) for d in dicts], chunksize=16)
    out = dict(res)
    write_json(out, path)
    return out


# ----------------------------------------------------------------------------------------------
# datasets
# ----------------------------------------------------------------------------------------------
class SceneDataset(Dataset):
    def __init__(self, cfg, scenes, stats, nav_cond=None, train=False, real_graph=False):
        self.cfg, self.scenes, self.stats = cfg, scenes, stats
        self.nav_cond = nav_cond or {}
        self.train, self.real_graph = train, real_graph

    def __len__(self):
        return len(self.scenes)

    def __getitem__(self, i):
        sc = self.scenes[i]
        c = self.cfg
        e = encode_scene(sc, c.data.max_objects, self.stats, c.graph.distance_threshold, c.ddpm.floor_mask_res,
                         self.nav_cond.get(sc.scene_id, c.ddpm.nav_target))
        if self.real_graph:
            e["adj_real"], e["rel_real"], e["ef_real"] = real_graph_arrays(sc, c.data.max_objects, c.graph.distance_threshold)
        if self.train:
            e = augment(e, np.random.randint(4), np.random.rand() < 0.5)
        return e


def to_device(b):
    return {k: (v.to(DEVICE) if torch.is_tensor(v) else v) for k, v in b.items()}


# ----------------------------------------------------------------------------------------------
# Module 2: GAT (relation encoder)
# ----------------------------------------------------------------------------------------------
def gat_key(cfg, seed):
    return key_of("gat", sub(cfg, "gat", "graph", "data.max_objects"), seed, cfg.paths.split_file)


def build_gat(cfg):
    g = cfg.gat
    return GAT(g.hidden_dim, g.heads, g.layers, g.cat_embed_dim)


def train_gat(cfg, seed, split, stats):
    out = os.path.join(cfg.paths.runs_dir, "gat", gat_key(cfg, seed))
    ck = os.path.join(out, "gat.pt")
    if os.path.exists(ck):
        return ck
    os.makedirs(out, exist_ok=True)
    set_seed(seed)
    log = log_to(os.path.join(out, "log.jsonl"))
    tr = SceneDataset(cfg, load_scenes(cfg, split["train"]), stats, real_graph=True)
    va = SceneDataset(cfg, load_scenes(cfg, split["val"]), stats, real_graph=True)
    dl = DataLoader(tr, cfg.gat.batch_size, shuffle=True, num_workers=4, drop_last=True)
    dv = DataLoader(va, cfg.gat.batch_size, num_workers=4)
    model = build_gat(cfg).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.gat.lr)

    def step(b, train):
        mask = b["mask"]
        ef = b["ef_real"].clone()
        if train:   # replace a share of the true distances by category-pair priors (see README)
            drop = torch.rand(ef.shape[:3], device=ef.device) < cfg.gat.prior_distance_dropout
            ef[..., 0] = torch.where(drop, b["ef"][..., 0], ef[..., 0])
        h = model(b["cats"], b["feats"], b["adj_real"], ef, mask)
        logits, dist = model.pair_logits(h)
        N = mask.shape[1]
        pm = mask[:, :, None] & mask[:, None, :] & ~torch.eye(N, dtype=torch.bool, device=mask.device)[None]
        l_rel = torch.nn.functional.cross_entropy(logits[pm], b["rel_real"][pm])
        l_dist = torch.nn.functional.mse_loss(dist[pm], b["ef_real"][..., 0][pm])
        return l_rel + l_dist

    best = np.inf
    for ep in range(cfg.gat.epochs):
        model.train()
        tl = []
        for b in dl:
            b = to_device(b)
            loss = step(b, True)
            opt.zero_grad()
            loss.backward()
            opt.step()
            tl.append(loss.item())
        model.eval()
        with torch.no_grad():
            vl = float(np.mean([step(to_device(b), False).item() for b in dv]))
        log({"epoch": ep, "train": float(np.mean(tl)), "val": vl})
        if vl < best:
            best = vl
            torch.save(model.state_dict(), ck)
    return ck


def load_gat(cfg, ck):
    m = build_gat(cfg)
    m.load_state_dict(torch.load(ck, map_location="cpu"))
    m.eval()
    for p in m.parameters():
        p.requires_grad_(False)
    return m


# ----------------------------------------------------------------------------------------------
# Module 3: navigation-conditioned DDPM
# ----------------------------------------------------------------------------------------------
def ddpm_key(cfg, seed, use_gat):
    return key_of("ddpm", sub(cfg, "ddpm", "data.max_objects", "graph"), use_gat, gat_key(cfg, seed) if use_gat else None,
                  seed, cfg.paths.split_file)


def build_ddpm(cfg, use_gat):
    d = cfg.ddpm
    model = Denoiser(d.model_dim, d.layers, d.heads, cfg.gat.hidden_dim, use_gat)
    diff = GaussianDiffusion(d.timesteps, d.beta_start, d.beta_end)
    return model, diff


def train_ddpm(cfg, seed, split, stats, nav_cond, gat=None):
    use_gat = gat is not None
    out = os.path.join(cfg.paths.runs_dir, "ddpm", ddpm_key(cfg, seed, use_gat))
    ck = os.path.join(out, "ddpm.pt")
    if os.path.exists(ck):
        return ck
    os.makedirs(out, exist_ok=True)
    set_seed(seed)
    log = log_to(os.path.join(out, "log.jsonl"))
    tr = SceneDataset(cfg, load_scenes(cfg, split["train"]), stats, nav_cond, train=True)
    va = SceneDataset(cfg, load_scenes(cfg, split["val"]), stats, nav_cond)
    dl = DataLoader(tr, cfg.ddpm.batch_size, shuffle=True, num_workers=4, drop_last=True)
    dv = DataLoader(va, cfg.ddpm.batch_size, num_workers=4)
    model, diff = build_ddpm(cfg, use_gat)
    model, diff = model.to(DEVICE), diff.to(DEVICE)
    if use_gat:
        gat = gat.to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.ddpm.lr)

    def g_of(b):
        if not use_gat:
            return None
        with torch.no_grad():
            return gat(b["cats"], b["feats"], b["adj"], b["ef"], b["mask"])

    best, bad = np.inf, 0
    for ep in range(cfg.ddpm.epochs):
        model.train()
        tl = []
        for b in dl:
            b = to_device(b)
            loss, parts = diff.loss(model, b, g_of(b), cfg.ddpm.lambda_spatial, cfg.ddpm.nav_cond_dropout)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            tl.append(loss.item())
        model.eval()
        with torch.no_grad():
            vl = []
            for b in dv:
                b = to_device(b)
                torch.manual_seed(1234)
                vl.append(diff.loss(model, b, g_of(b), cfg.ddpm.lambda_spatial, 0.0)[0].item())
        vl = float(np.mean(vl))
        log({"epoch": ep, "train": float(np.mean(tl)), "val": vl})
        if vl < best:
            best, bad = vl, 0
            torch.save(model.state_dict(), ck)
        else:
            bad += 1
            if bad >= cfg.ddpm.early_stop_patience:      # early stopping on the validation set (4.1.1)
                log(f"early stop at epoch {ep}")
                break
    return ck


def load_ddpm(cfg, ck, use_gat):
    model, diff = build_ddpm(cfg, use_gat)
    model.load_state_dict(torch.load(ck, map_location="cpu"))
    model.eval()
    return model.to(DEVICE), diff.to(DEVICE)


@torch.no_grad()
def generate_ddpm(cfg, model, diff, gat, templates, stats, n_candidates, seed, batch=64, return_steps=()):
    """Generates n_candidates layouts for each template room (object list + floor plan)."""
    set_seed(seed)
    ds = SceneDataset(cfg, templates, stats, {s.scene_id: cfg.ddpm.nav_target for s in templates})
    out = [[] for _ in templates]
    steps = {}
    if gat is not None:
        gat = gat.to(DEVICE)
    for c in range(n_candidates):
        for s0 in range(0, len(ds), batch):
            items = [ds[i] for i in range(s0, min(s0 + batch, len(ds)))]
            b = to_device(torch.utils.data.default_collate(items))
            g = gat(b["cats"], b["feats"], b["adj"], b["ef"], b["mask"]) if gat is not None else None
            res = diff.sample(model, b, g, cfg.ddpm.guidance_scale, return_steps=return_steps)
            x, keep = res if return_steps else (res, {})
            x = x.cpu().numpy()
            for j in range(len(items)):
                out[s0 + j].append(decode_pose(templates[s0 + j], x[j]))
                if return_steps and c == 0:
                    steps[templates[s0 + j].scene_id] = {t: decode_pose(templates[s0 + j], v[j].cpu().numpy())
                                                         for t, v in keep.items()}
    return (out, steps) if return_steps else out


# ----------------------------------------------------------------------------------------------
# Module 6: PPO refinement
# ----------------------------------------------------------------------------------------------
def ppo_key(cfg, seed, start_key, use_gat, reward_mode, constrained):
    return key_of("ppo", sub(cfg, "ppo", "monff", "navigation", "collision", "graph", "data.max_objects"),
                  start_key, gat_key(cfg, seed) if use_gat else None, reward_mode, constrained, seed, cfg.paths.split_file)


def train_ppo(cfg, seed, start_scenes, start_key, stats, gat=None, reward_mode="monff", constrained=True, n_envs=8):
    out = os.path.join(cfg.paths.runs_dir, "ppo", ppo_key(cfg, seed, start_key, gat is not None, reward_mode, constrained))
    ck = os.path.join(out, "policy.pt")
    if os.path.exists(ck):
        return ck
    os.makedirs(out, exist_ok=True)
    set_seed(seed)
    policy = Policy(gat.to(DEVICE) if gat is not None else None, cfg.ppo.model_dim).to(DEVICE)
    venv = VecEnv(cfg, stats, [s.to_dict() for s in start_scenes], n_envs, reward_mode, constrained, seed)
    try:
        hist = ppo_train(policy, venv, cfg, DEVICE, log=log_to(os.path.join(out, "log.jsonl")))
    finally:
        venv.close()
    sd = {k: v for k, v in policy.state_dict().items() if not k.startswith("gat.")}
    torch.save(sd, ck)
    write_json(hist, os.path.join(out, "history.json"))
    return ck


_W = {}


def _refine_init(cfg, stats, policy_ck, gat_ck, reward_mode, constrained):
    torch.set_num_threads(1)
    gat = load_gat(cfg, gat_ck) if gat_ck else None
    pol = Policy(gat, cfg.ppo.model_dim)
    pol.load_state_dict(torch.load(policy_ck, map_location="cpu"), strict=False)
    pol.eval()
    _W.update(cfg=cfg, stats=stats, policy=pol, env=RefineEnv(cfg, stats, reward_mode, constrained))


def _refine_one(args):
    d, seed = args
    sc, comp = refine(_W["policy"], _W["env"], Scene.from_dict(d), torch.device("cpu"), seed=seed)
    return sc.to_dict(), comp


def refine_many(cfg, stats, scenes, policy_ck, gat_ck, reward_mode, constrained, seed, workers=8):
    args = [(s.to_dict(), seed * 100003 + i) for i, s in enumerate(scenes)]
    with mp.get_context("spawn").Pool(workers, initializer=_refine_init,
              initargs=(cfg, stats, policy_ck, gat_ck, reward_mode, constrained)) as pool:
        res = pool.map(_refine_one, args, chunksize=2)
    return [(Scene.from_dict(d), c) for d, c in res]


def _score_init(cfg, stats, mode):
    _W.update(cfg=cfg, stats=stats, mode=mode)


def _score_one(d):
    sc = Scene.from_dict(d)
    return evaluate_layout(sc, _W["cfg"], _W["stats"], sample_pairs(sc, _W["cfg"].navigation), "dijkstra", _W["mode"])


def score_many(cfg, stats, scenes, mode, workers=8):
    with mp.get_context("spawn").Pool(workers, initializer=_score_init, initargs=(cfg, stats, mode)) as pool:
        return pool.map(_score_one, [s.to_dict() for s in scenes], chunksize=4)


# ----------------------------------------------------------------------------------------------
# full experiment for one seed and one model variant
# ----------------------------------------------------------------------------------------------
VARIANTS = {
    #            generator    use_gat  ppo     reward    constrained
    "full":         ("ddpm",      True,  True,  "monff", True),
    "no_gat":       ("ddpm",      False, True,  "monff", True),
    "no_ddpm":      ("heuristic", True,  True,  "monff", True),
    "no_ppo":       ("ddpm",      True,  False, "monff", True),
    "no_monff":     ("ddpm",      True,  True,  "ans",   True),
    "unconstrained": ("ddpm",     True,  True,  "monff", False),
}


def run_variant(cfg, seed, variant, workers=8, n_envs=8, test_ids=None, tag=None, test_dir=None):
    gen, use_gat, use_ppo, reward_mode, constrained = VARIANTS[variant]
    split = load_split(cfg.paths.split_file)
    stats = prepare_stats(cfg, split)
    nav_cond = prepare_nav_cond(cfg, split, workers)
    run_key = key_of("run", cfg, seed, variant)
    out = os.path.join(cfg.paths.runs_dir, "outputs", tag or "main", variant, f"seed{seed}")
    if os.path.exists(os.path.join(out, "done.json")):
        return out
    os.makedirs(out, exist_ok=True)
    t0 = time.time()
    gat_ck = train_gat(cfg, seed, split, stats) if use_gat else None
    gat = load_gat(cfg, gat_ck) if gat_ck else None
    if test_dir:
        test = [Scene.load(os.path.join(test_dir, f)) for f in sorted(os.listdir(test_dir)) if f.endswith(".json")]
    else:
        test = load_scenes(cfg, test_ids or split["test"])
    r = cfg.ddpm.candidates_per_room

    # Module 3: candidate layouts
    if gen == "ddpm":
        ddpm_ck = train_ddpm(cfg, seed, split, stats, nav_cond, gat)
        model, diff = load_ddpm(cfg, ddpm_ck, use_gat)
        cands = generate_ddpm(cfg, model, diff, gat, test, stats, r, seed)
        start_key = ddpm_key(cfg, seed, use_gat)
    else:
        rng = np.random.default_rng(seed)
        cands = [[heuristic_layout(t, stats, rng) for _ in range(r)] for t in test]
        ddpm_ck = train_ddpm(cfg, seed, split, stats, nav_cond, gat)      # PPO is trained on DDPM layouts
        model, diff = load_ddpm(cfg, ddpm_ck, True)
        start_key = ddpm_key(cfg, seed, True)

    # Module 6: PPO refinement + MONFF selection (S* = argmax MONFF)
    flat = [c for cs in cands for c in cs]
    if use_ppo:
        starts_dir = os.path.join(cfg.paths.runs_dir, "ppo_starts", start_key)
        starts = _ppo_starts(cfg, seed, split, stats, model, diff, gat, starts_dir)
        pol_ck = train_ppo(cfg, seed, starts, start_key, stats, gat, reward_mode, constrained, n_envs)
        res = refine_many(cfg, stats, flat, pol_ck, gat_ck, reward_mode, constrained, seed, workers)
        refined = [x[0] for x in res]
        scores = [x[1]["score"] for x in res]
    else:
        refined = flat
        scores = [c["score"] for c in score_many(cfg, stats, flat, reward_mode, workers)]
    os.makedirs(os.path.join(out, "scenes"), exist_ok=True)
    os.makedirs(os.path.join(out, "pre"), exist_ok=True)
    for i, t in enumerate(test):
        idx = list(range(i * r, (i + 1) * r))
        j = max(idx, key=lambda k: scores[k])
        refined[j].save(os.path.join(out, "scenes", t.scene_id + ".json"))
        flat[j].save(os.path.join(out, "pre", t.scene_id + ".json"))
    write_json({"seed": seed, "variant": variant, "run_key": run_key, "minutes": (time.time() - t0) / 60},
               os.path.join(out, "done.json"))
    return out


def _ppo_starts(cfg, seed, split, stats, model, diff, gat, out_dir):
    """Generated layouts of training rooms used as PPO start states."""
    if os.path.exists(os.path.join(out_dir, "done")):
        return [Scene.load(os.path.join(out_dir, f)) for f in sorted(os.listdir(out_dir)) if f.endswith(".json")]
    os.makedirs(out_dir, exist_ok=True)
    rng = np.random.default_rng(seed)
    ids = list(rng.choice(split["train"], min(cfg.ppo.n_train_layouts, len(split["train"])), replace=False))
    tmpl = load_scenes(cfg, ids)
    layouts = [c[0] for c in generate_ddpm(cfg, model, diff, gat, tmpl, stats, 1, seed)]
    for s in layouts:
        s.save(os.path.join(out_dir, s.scene_id + ".json"))
    open(os.path.join(out_dir, "done"), "w").close()
    return layouts
