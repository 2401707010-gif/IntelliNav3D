"""Statistics of Section 4.7: mean, sample SD and t-based 95% CI over seeds; paired t-tests with Holm correction."""
import numpy as np
from scipy import stats as st


def summary(values):
    v = np.asarray(values, float)
    n = len(v)
    mean = float(v.mean())
    sd = float(v.std(ddof=1)) if n > 1 else 0.0
    half = float(st.t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else float("nan")
    return {"n": n, "mean": mean, "sd": sd, "ci95": half}


def paired_test(a, b):
    """a, b: per-seed values of two methods evaluated on the same test scenes and start-goal pairs."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = a - b
    n = len(d)
    mean = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else 0.0
    half = float(st.t.ppf(0.975, n - 1) * sd / np.sqrt(n)) if n > 1 else float("nan")
    p = float(st.ttest_rel(a, b).pvalue) if n > 1 and sd > 0 else float("nan")
    return {"n": n, "mean_diff": mean, "ci_low": mean - half, "ci_high": mean + half, "p": p}


def holm(pvals):
    """Holm-Bonferroni adjusted p-values (same order as the input)."""
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, min(1.0, (m - rank) * p[i]))
        adj[i] = run
    return adj.tolist()
